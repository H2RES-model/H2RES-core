﻿# H2RES v1.0

## Overview
H2RES v1.0 is the first public single-system version of the H2RES energy system optimization model. It combines long-term planning and hourly operation across electricity, heat, cooling, hydrogen, storage, and policy constraints within one integrated optimization framework.

## What this version represents
This version establishes the original H2RES mathematical structure and the baseline sector-coupled formulation. It is the reference point for understanding how the model was first organized before later changes in preprocessing, rolling-horizon execution, and multizone structure.

## Core capabilities
- Unit-level generation bounds
- Dispatchable generation with ramping limits and ramping costs
- Non-dispatchable renewable generation with availability profiles
- Hydropower reservoirs and pumped-hydro storage
- CHP units and thermal storage
- Power-to-heat through heat pumps and boilers
- Stationary battery storage
- EV flexibility and storage
- Electrolyzers, hydrogen storage, and fuel cells
- Industrial fuel switching with hydrogen substitution
- Renewable portfolio standard constraints
- CO2-emission accounting and carbon-cap constraints
- Optional primary and secondary reserve modules
- Curtailment / unmet electricity service through `ceep`

## Core decision variables in this version
- `generation_{u,t,y}`
- `imports_{t,y}`
- `ceep_{t,y}`
- `cap_inv_{u,y}`
- `generation_FC_{c,t,y}`
- `generation_H2_{e,t,y}`
- `storage_level_{u,t,y}`
- `stat_sto_soc_{b,t,y}` and `ev_sto_soc_{t,y}`
- `heat_pump_*`, `boiler_*`, and CHP heat variables

## Main formulation blocks
- Capacity expansion and effective-capacity accounting
- Electricity balance with sector-coupling loads
- Heat and cooling service balances
- Hydrogen production, storage, and demand balances
- Storage state-of-charge recursions across carriers
- Hydro reservoir and pumped-hydro dynamics
- Ramping, RPS, and CO2-policy constraints

## Main workflow
The standard execution path is based on:
- `main.py`
- `scripts/read_process_data.py`
- `scripts/Build_model.py`

## Recommended use
Use v1.0 to understand the original H2RES structure and the baseline sector-coupled mathematical formulation.

## Related documentation
For a full description of model structure, equations, data flow, and interpretation logic, see the corresponding User Manual and Mathematical Formulation documents for this version.

## Caution on cross-version comparison
Later versions introduce important changes in data engineering, temporal execution logic, and model scope. Results from v1.0 should not be compared directly with later versions unless assumptions and workflow are aligned.
