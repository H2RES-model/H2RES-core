import matplotlib.pyplot as plt

pal2 = ['black', 'dimgray','silver', 'lightskyblue', 'blue','yellowgreen','red', 'royalblue','brown','darkorange','seagreen']
col_name22 = ['Coal','Diesel','Oil','Gas','LPG','Biomass','Nuclear','Hydro','imports', 'Wind', 'Solar']
col_name = ['Coal','Diesel','Oil','Gas','Biomass','Nuclear','Hydro','imports', 'Wind','Solar']

#gen=gen.drop('level_0',axis = 1)


gen = gen.reset_index()
if len(gen['year'].unique()) != 1:
    fig, axs = plt.subplots(len(gen['year'].unique()), sharex=False, figsize=(10, 12))
    for i, year in enumerate(gen['year'].unique()):
        data_plot = gen[gen['year'] == year]
        
        # Use concat instead of append
        data_plot2 = pd.concat([pd.DataFrame(columns=col_name22), data_plot]).fillna(0)
        
        data_demand = pd.DataFrame(df_demand[df_demand['year'] == year])
        data_demand['total'] = data_demand[demand_sectors].sum(axis=1)
        data_demand = data_demand.set_index('period')
        
        axs[i].stackplot(data_plot2.period, data_plot2[col_name22].T, colors=pal2, alpha=0.8, labels=col_name22)
        axs[i].plot(data_demand.index, data_demand['total'], color='purple', alpha=0.2)
        axs[i].set_title(str(year))
        axs[i].set(xlabel='Period', ylabel='[MWh]')
        handles, labels = axs[i].get_legend_handles_labels()
    
    fig.legend(handles, labels, loc='right', fontsize='large', bbox_to_anchor=(1.2, 0.4), labels=None, prop={'size': 12})
    plt.subplots_adjust(left=0, bottom=0.1, right=0.9, top=0.85, wspace=1, hspace=0.45)
    plt.tight_layout()
    plt.savefig('./results/' + scen + '/generation_year.png', bbox_inches='tight')
    plt.show()
    
    # Plot for total generation by year
    gen_plot = gen.drop('period', axis=1).groupby('year').sum()
    
    # Use concat instead of append
    data_plot_cum = pd.concat([pd.DataFrame(columns=col_name22), gen_plot]).fillna(0)
    
    plt.figure(figsize=(12, 6))
    data_plot_cum.plot(kind='bar', stacked=True, color=pal2)
    plt.legend(col_name22, loc='right', fontsize='large', bbox_to_anchor=(1.35, 0.4), prop={'size': 12})
    plt.ylabel('Generation (MWh)')
    plt.title('Total Generation')
    plt.savefig('./results/' + scen + '/gen_year.png', bbox_inches='tight')
    plt.show()


if len(gen['year'].unique()) == 1:
    year = gen['year'].unique()[0]
    data_plot = gen[gen['year'] == year]
    
    # Use concat instead of append
    data_plot2 = pd.concat([pd.DataFrame(columns=col_name22), data_plot]).fillna(0)
    
    data_demand = pd.DataFrame(df_demand[df_demand['year'] == year])
    data_demand['total'] = data_demand[demand_sectors].sum(axis=1)
    data_demand = data_demand.set_index('period')
    
    plt.figure(figsize=(12, 6))
    plt.stackplot(data_plot2.period, data_plot2[col_name22].T, colors=pal2, alpha=0.8, labels=col_name22)
    plt.legend(col_name22, loc='right', fontsize='large', bbox_to_anchor=(1.2, 0.4), prop={'size': 12})
    plt.xlabel('Period')
    plt.ylabel('[MWh]')
    plt.title(str(year))
    plt.tight_layout()
    plt.savefig('./results/' + scen + '/generation_year.png', bbox_inches='tight')
    plt.show()
    
    # Plot for total generation by year
    gen_plot = gen.drop('period', axis=1).groupby('year').sum()
    
    # Use concat instead of append
    data_plot_cum = pd.concat([pd.DataFrame(columns=col_name22), gen_plot]).fillna(0)
    
    plt.figure(figsize=(12, 6))
    data_plot_cum.plot(kind='bar', stacked=True, color=pal2)
    plt.legend(col_name22, loc='right', fontsize='large', bbox_to_anchor=(1.35, 0.4), prop={'size': 12})
    plt.ylabel('Generation (MWh)')
    plt.title('Total Generation')
    plt.savefig('./results/' + scen + '/gen_year.png', bbox_inches='tight')
    plt.show()

################################HYDRO STORAGE PLOT###################################################################
hydro_soc = storage_total_df.reset_index()

if len(hydro_soc['year'].unique()) != 1:
    fig, axs = plt.subplots(len(hydro_soc['year'].unique()), sharex=False, figsize=(10, 12))
    for i, year in enumerate(hydro_soc['year'].unique()):
        data_plot = hydro_soc[hydro_soc['year'] == year]
        
        # Use concat instead of append
        data_plot2 = pd.concat([pd.DataFrame(columns=hydro_soc.columns[2:]), data_plot]).fillna(0)
        
        axs[i].stackplot(data_plot2.period, data_plot2[hydro_soc.columns[2:]].T, colors=pal2, alpha=0.8, labels=hydro_soc.columns[2:])
        axs[i].set_title(str(year))
        axs[i].set(xlabel='Period', ylabel='[MWh]')
        handles, labels = axs[i].get_legend_handles_labels()
    
    fig.legend(handles, labels, loc='right', fontsize='large', bbox_to_anchor=(1.3, 0.4), labels=None, prop={'size': 12})
    plt.subplots_adjust(left=0, bottom=0.1, right=0.9, top=0.85, wspace=1, hspace=0.45)
    plt.tight_layout()
    plt.savefig('./results/' + scen + '/hydro_storage_level.png', bbox_inches='tight')
    plt.show()

if len(hydro_soc['year'].unique()) == 1:
    year = hydro_soc['year'].unique()[0]
    data_plot = hydro_soc[hydro_soc['year'] == year]
    
    # Use concat instead of append
    data_plot2 = pd.concat([pd.DataFrame(columns=hydro_soc.columns[2:]), data_plot]).fillna(0)
    
    plt.figure(figsize=(12, 6))
    plt.stackplot(data_plot2.period, data_plot2[hydro_soc.columns[2:]].T, colors=pal2, alpha=0.8, labels=hydro_soc.columns[2:])
    plt.legend(hydro_soc.columns[2:], loc='right', fontsize='large', bbox_to_anchor=(1.3, 0.4), prop={'size': 12})
    plt.xlabel('Period')
    plt.ylabel('[MWh]')
    plt.title(str(year))
    plt.tight_layout()
    plt.savefig('./results/' + scen + '/hydro_storage_level.png', bbox_inches='tight')
    plt.show()

################################Power To X###################################################################      

PtX_plot = PowerTo_Sto_Heat_EV.reset_index()

# For multiple unique years
if len(PtX_plot['year'].unique()) != 1:
    fig, axs = plt.subplots(len(PtX_plot['year'].unique()), sharex=False, figsize=(10, 12))
    for i, year in enumerate(PtX_plot['year'].unique()):
        data_plot = PtX_plot[PtX_plot['year'] == year]
        
        # Ensure 'period' column is included and use concat instead of append
        relevant_columns = ['period'] + list(PtX_plot.columns[2:])
        data_plot2 = pd.concat([data_plot[relevant_columns]]).fillna(0)
        # data_plot2 = data_plot2.drop(['unit_y'],axis = 1)
        # data_plot2 = data_plot2.drop(['unit_x'],axis = 1)


        # Use data_plot2['period'] for the x-axis and data_plot2.drop(columns=['period']).values.T for the y-axis values
        axs[i].stackplot(data_plot2['period'], data_plot2.drop(columns=['period']).values.T, alpha=0.8, labels=PtX_plot.columns[2:])
        title = 'Power to X in {}'.format(year)
        axs[i].set_title(title)
        axs[i].set(xlabel='Period', ylabel='[MWh]')
        handles, labels = axs[i].get_legend_handles_labels()
    
    fig.legend(handles, labels, loc='right', fontsize='large', bbox_to_anchor=(1.3, 0.4))
    plt.subplots_adjust(left=0, bottom=0.1, right=0.9, top=0.85, wspace=1, hspace=0.45)
    plt.tight_layout()
    plt.savefig('./results/' + scen + '/Power_to_X.png', bbox_inches='tight')
    plt.show()

# For a single unique year
if len(PtX_plot['year'].unique()) == 1:
    year = PtX_plot['year'].unique()[0]
    data_plot = PtX_plot[PtX_plot['year'] == year]
    
    # Ensure 'period' column is included and use concat instead of append
    relevant_columns = ['period'] + list(PtX_plot.columns[2:])
    data_plot2 = pd.concat([data_plot[relevant_columns]]).fillna(0)
    data_plot2 = data_plot2.drop(['unit_y'],axis = 1)
    data_plot2 = data_plot2.drop(['unit_x'],axis = 1)
    
    plt.figure(figsize=(12, 6))
    plt.stackplot(data_plot2['period'], data_plot2.drop(columns=['period']).values.T, alpha=0.8, labels=PtX_plot.columns[2:])
    plt.legend(PtX_plot.columns[2:], loc='right', fontsize='large', bbox_to_anchor=(1.3, 0.4))
    title = 'Power to X in {}'.format(year)
    plt.title(title)
    plt.xlabel('Period')
    plt.ylabel('[MWh]')
    plt.tight_layout()
    plt.savefig('./results/' + scen + '/Power_to_X.png', bbox_inches='tight')
    plt.show()




################################Industry###################################################################


fuel_use_ind_plot = fuel_use_ind_df.reset_index()

# For multiple unique years
if len(fuel_use_ind_plot['year'].unique()) != 1:
    fig, axs = plt.subplots(len(fuel_use_ind_plot['year'].unique()), sharex=False, figsize=(10, 12))
    for i, year in enumerate(fuel_use_ind_plot['year'].unique()):
        data_plot = fuel_use_ind_plot[fuel_use_ind_plot['year'] == year]
        
        # Use concat instead of append
        data_plot2 = pd.concat([pd.DataFrame(columns=fuel_use_ind_plot.columns[2:]), data_plot]).fillna(0)
        
        axs[i].stackplot(data_plot2.period, data_plot2[fuel_use_ind_plot.columns[2:]].T, alpha=0.8, labels=fuel_use_ind_plot.columns[2:])
        title = 'Industry fuel use in {}'.format(year)
        axs[i].set_title(title)
        axs[i].set(xlabel='Period', ylabel='[MWh]')
        handles, labels = axs[i].get_legend_handles_labels()
    
    fig.legend(handles, labels, loc='right', fontsize='large', bbox_to_anchor=(1.3, 0.4))
    plt.subplots_adjust(left=0, bottom=0.1, right=0.9, top=0.85, wspace=1, hspace=0.45)
    plt.tight_layout()
    plt.savefig('./results/' + scen + '/Industry_fuel_use.png', bbox_inches='tight')
    plt.show()

# For a single unique year
if len(fuel_use_ind_plot['year'].unique()) == 1:
    year = fuel_use_ind_plot['year'].unique()[0]
    data_plot = fuel_use_ind_plot[fuel_use_ind_plot['year'] == year]
    
    # Use concat instead of append
    data_plot2 = pd.concat([pd.DataFrame(columns=fuel_use_ind_plot.columns[2:]), data_plot]).fillna(0)
    
    plt.figure(figsize=(12, 6))
    plt.stackplot(data_plot2.period, data_plot2[fuel_use_ind_plot.columns[2:]].T, alpha=0.8, labels=fuel_use_ind_plot.columns[2:])
    plt.legend(fuel_use_ind_plot.columns[2:], loc='right', fontsize='large', bbox_to_anchor=(1.3, 0.4))
    title = 'Industry fuel use in {}'.format(year)
    plt.title(title)
    plt.xlabel('Period')
    plt.ylabel('[MWh]')
    plt.tight_layout()
    plt.savefig('./results/' + scen + '/Industry_fuel_use.png', bbox_inches='tight')
    plt.show()

        
        
