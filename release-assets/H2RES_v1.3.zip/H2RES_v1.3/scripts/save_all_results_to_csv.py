# -*- coding: utf-8 -*-
"""
Guardar TODOS los diccionarios *_results a CSV.

Diccionarios considerados explícitamente:

    generation_results
    imports_results
    imports_from_results
    ceep_results
    cap_inv_results
    noload_elec_results
    noload_heat_ind_results
    noload_heat_dh_results
    CO2_total_results
    CO2_total_heat_results
    CO2_total_industry_results
    cap_inv_FC_results
    generation_FC_results
    storage_level_results
    sto_out_flow_results
    heat_gen_results
    Fuel_ind_results
    H2tInd_results
    heat_pump_dh_results
    heat_pump_ind_results
    heat_pump_dh_cap_results
    heat_pump_ind_cap_results
    boiler_dh_generation_results
    boiler_ind_generation_results
    trad_boiler_ind_cap_inv_results
    trad_boiler_dh_cap_inv_results
    ResToHeat_results
    ev_sto_in_results
    ev_sto_out_results
    ev_sto_soc_results
    stat_sto_in_results
    stat_sto_out_results
    stat_sto_cap_inv_results
    power_to_h2_results
    h2_sto_soc_results
    h2_sto_out_results
    h2_sto_max_cap_results
    h2_electrolysis_max_cap_results
    generation_H2_results
    transfer_inv_results

Comportamiento especial para generation_results:
    - Se generan archivos por región, agregados por combustible + shed_load:
      generation_by_fuel_<Region>.csv

El resto de diccionarios se exportan como un CSV cada uno, con nombres de columnas
semánticos (Region, Unit, Period, Year, etc.), según la estructura del diccionario.
"""

import os
import pandas as pd

# Carpeta base: ./results/<scen>/data_result
base_dir = os.path.join('.', 'results', scen, 'data_result')
os.makedirs(base_dir, exist_ok=True)

print(f'Guardando diccionarios *_results en: {base_dir}')

# Lista explícita de diccionarios en el orden deseado
RESULT_NAMES = [
    "generation_results",
    "imports_results",
    "imports_from_results",
    "ceep_results",
    "cap_inv_results",
    "noload_elec_results",
    "noload_heat_ind_results",
    "noload_heat_dh_results",
    "CO2_total_results",
    "CO2_total_heat_results",
    "CO2_total_industry_results",
    "cap_inv_FC_results",
    "generation_FC_results",
    "storage_level_results",
    "sto_out_flow_results",
    "heat_gen_results",
    "Fuel_ind_results",
    "H2tInd_results",
    "heat_pump_dh_results",
    "heat_pump_ind_results",
    "heat_pump_dh_cap_results",
    "heat_pump_ind_cap_results",
    "boiler_dh_generation_results",
    "boiler_ind_generation_results",
    "trad_boiler_ind_cap_inv_results",
    "trad_boiler_dh_cap_inv_results",
    "ResToHeat_results",
    "ev_sto_in_results",
    "ev_sto_out_results",
    "ev_sto_soc_results",
    "stat_sto_in_results",
    "stat_sto_out_results",
    "stat_sto_cap_inv_results",
    "power_to_h2_results",
    "h2_sto_soc_results",
    "h2_sto_out_results",
    "h2_sto_max_cap_results",
    "h2_electrolysis_max_cap_results",
    "generation_H2_results",
    "transfer_inv_results",
]

# Mapeo de diccionario -> nombres de columnas para la llave + 'Value'
COLUMNS_MAP = {
    "imports_results":                 ["Region", "Period", "Year", "Value"],
    "imports_from_results":            ["RegionTo", "RegionFrom", "Period", "Year", "Value"],
    "ceep_results":                    ["Region", "Period", "Year", "Value"],
    "cap_inv_results":                 ["Region", "Unit", "Year", "Value"],
    "noload_elec_results":             ["Region", "Period", "Year", "Value"],
    "noload_heat_ind_results":         ["Region", "Period", "Year", "Value"],
    "noload_heat_dh_results":          ["Region", "Unit", "Period", "Year", "Value"],
    "CO2_total_results":               ["Region", "Year", "Value"],
    "CO2_total_heat_results":          ["Region", "Year", "Value"],
    "CO2_total_industry_results":      ["Region", "Year", "Value"],
    "cap_inv_FC_results":              ["Region", "Unit", "Year", "Value"],
    "generation_FC_results":           ["Region", "Unit", "Period", "Year", "Value"],
    "storage_level_results":           ["Region", "Unit", "Period", "Year", "Value"],
    "sto_out_flow_results":            ["Region", "Unit", "Period", "Year", "Value"],
    "heat_gen_results":                ["Region", "Unit", "Period", "Year", "Value"],
    "Fuel_ind_results":                ["Region", "Fuel", "Period", "Year", "Value"],
    "H2tInd_results":                  ["Region", "Period", "Year", "Value"],
    "heat_pump_dh_results":            ["Region", "CHP", "Unit", "Period", "Year", "Value"],
    "heat_pump_ind_results":           ["Region", "Unit", "Period", "Year", "Value"],
    "heat_pump_dh_cap_results":        ["Region", "CHP", "Unit", "Year", "Value"],
    "heat_pump_ind_cap_results":       ["Region", "Unit", "Year", "Value"],
    "boiler_dh_generation_results":    ["Region", "CHP", "Unit", "Period", "Year", "Value"],
    "boiler_ind_generation_results":   ["Region", "Unit", "Period", "Year", "Value"],
    "trad_boiler_ind_cap_inv_results": ["Region", "Unit", "Year", "Value"],
    "trad_boiler_dh_cap_inv_results":  ["Region", "CHP", "Unit", "Year", "Value"],
    "ResToHeat_results":               ["Region", "Period", "Year", "Value"],
    "ev_sto_in_results":               ["Region", "Period", "Year", "Value"],
    "ev_sto_out_results":              ["Region", "Period", "Year", "Value"],
    "ev_sto_soc_results":              ["Region", "Period", "Year", "Value"],
    "stat_sto_in_results":             ["Region", "Unit", "Period", "Year", "Value"],
    "stat_sto_out_results":            ["Region", "Unit", "Period", "Year", "Value"],
    "stat_sto_cap_inv_results":        ["Region", "Unit", "Year", "Value"],
    "power_to_h2_results":             ["Region", "Period", "Year", "Value"],
    "h2_sto_soc_results":              ["Region", "Unit", "Period", "Year", "Value"],
    "h2_sto_out_results":              ["Region", "Unit", "Period", "Year", "Value"],
    "h2_sto_max_cap_results":          ["Region", "Unit", "Year", "Value"],
    "h2_electrolysis_max_cap_results": ["Region", "Unit", "Year", "Value"],
    "generation_H2_results":           ["Region", "Unit", "Period", "Year", "Value"],
    "transfer_inv_results":            ["RegionTo", "RegionFrom", "Year", "Value"],
    # generation_results se trata aparte
}


# =============================================================================
# 1) Tratamiento especial: generation_results -> por región y por combustible + shed_load
# =============================================================================

def export_generation_by_fuel():
    """
    Usa:
        - generation_results[(region, unit, period, year)]
        - noload_elec_results[(region, period, year)]  -> shed_load
        - df (metadata de unidades, con columna 'fuel' o 'fuel_type')
        - unit_system, systems, years, periods

    Genera:
        generation_by_fuel_<Region>.csv con columnas:
            Region, Year, Period, Fuel, Value
    """
    if 'generation_results' not in globals():
        print("  - generation_results no encontrado en globals(), se omite.")
        return

    gen_dict = generation_results

    if not gen_dict:
        print("  - generation_results vacío, se omite.")
        return

    # Determinar columna de combustible en df
    global df
    if 'fuel' in df.columns:
        fuel_col_name = 'fuel'
    elif 'fuel_type' in df.columns:
        fuel_col_name = 'fuel_type'
    else:
        fuel_col_name = None
        print("  WARNING: df no tiene 'fuel' ni 'fuel_type'; se usará 'Other' como Fuel.")

    for region in systems:
        rows = []

        for year in years:
            # Generación por unidad -> combustible
            for unit in unit_system[region]:
                # Buscar fuel en df
                if fuel_col_name is not None:
                    fuel_row = df[
                        (df['unit_name'] == unit) &
                        (df['system'] == region)
                    ]
                    if not fuel_row.empty:
                        fuel = fuel_row[fuel_col_name].iloc[0]
                    else:
                        fuel = 'Other'
                else:
                    fuel = 'Other'

                for period in periods:
                    key = (region, unit, period, year)
                    if key not in gen_dict:
                        continue
                    val = gen_dict[key]
                    rows.append([region, year, period, fuel, val])

            # Añadir shed_load a partir de noload_elec_results
            if 'noload_elec_results' in globals():
                for period in periods:
                    key_shed = (region, period, year)
                    if key_shed not in noload_elec_results:
                        continue
                    val_shed = noload_elec_results[key_shed]
                    rows.append([region, year, period, 'shed_load', val_shed])

        if not rows:
            print(f'  - generation_by_fuel_{region}: sin filas, se omite.')
            continue

        df_region = pd.DataFrame(rows,
                                 columns=['Region', 'Year', 'Period', 'Fuel', 'Value'])

        # Agregar por Region-Year-Period-Fuel (en caso de duplicados)
        df_region = (df_region
                     .groupby(['Region', 'Year', 'Period', 'Fuel'], as_index=False)
                     .sum())

        out_path = os.path.join(base_dir, f'generation_by_fuel_{region}.csv')
        df_region.to_csv(out_path, index=False)
        print(f'  - generation_by_fuel_{region}: {len(df_region)} filas -> {out_path}')


# Ejecutar exportación especial de generación
export_generation_by_fuel()

# No queremos exportar generation_results de forma genérica
RESULT_NAMES_NO_GEN = [name for name in RESULT_NAMES if name != 'generation_results']

# =============================================================================
# 2) Tratamiento estándar para el resto de diccionarios *_results
# =============================================================================

for name in RESULT_NAMES_NO_GEN:
    if name not in globals():
        print(f'  - {name}: no existe en globals(), se omite.')
        continue

    d = globals()[name]

    if not isinstance(d, dict):
        print(f'  - {name}: no es un dict, se omite.')
        continue

    if not d:
        print(f'  - {name}: diccionario vacío, se omite.')
        continue

    rows = []
    for key, value in d.items():
        if not isinstance(key, tuple):
            key = (key,)
        rows.append(list(key) + [value])

    # Si hay definición de nombres de columna, la usamos.
    if name in COLUMNS_MAP:
        col_names = COLUMNS_MAP[name]
        # Sanidad: comprobar que encaja el número de columnas
        if len(col_names) != len(rows[0]):
            # Fallback genérico si la longitud no coincide
            idx_cols = [f'idx{i+1}' for i in range(len(rows[0]) - 1)]
            col_names = idx_cols + ['Value']
            print(f"  WARNING: {name} longitud de llave inesperada, se usan columnas genéricas {col_names}")
    else:
        # Fallback genérico si el diccionario no está mapeado
        idx_cols = [f'idx{i+1}' for i in range(len(rows[0]) - 1)]
        col_names = idx_cols + ['Value']
        print(f"  WARNING: {name} no está en COLUMNS_MAP, se usan columnas genéricas {col_names}")

    df = pd.DataFrame(rows, columns=col_names)

    out_path = os.path.join(base_dir, f'{name}.csv')
    df.to_csv(out_path, index=False)
    print(f'  - {name}: guardadas {len(df)} filas en {out_path}')

print('Exportación de diccionarios *_results completada.')
