# -*- coding: utf-8 -*-
"""
Created on Fri Jan  8 18:44:57 2021
@author: Felipe Feijoo
"""
#%%
#create UCP model
import gurobipy as gp
from gurobipy import GRB


#import os

#%%
print('Building the model--> ...')
ucp = gp.Model('PowerGeneration')

##################################################################################################################################################################
###############################Variables##########################################################################################################################
##################################################################################################################################################################
rampup_cost         = ucp.addVars(system_unit_cap.keys(), periods,years,    vtype=GRB.CONTINUOUS, lb=0,  name = 'ramp_up_cost_var')
rampdown_cost       = ucp.addVars(system_unit_cap.keys(), periods,years,    vtype=GRB.CONTINUOUS, lb=0,  name = 'ramp_cown_cost_var')
generation          = ucp.addVars(system_unit_cap.keys(), periods, years,   vtype=GRB.CONTINUOUS, lb=0,  name = 'gen_output')
cap_inv             = ucp.addVars(system_unit_cap.keys(), years,            vtype=GRB.CONTINUOUS, lb=0,  name = 'capacity_Investment')
ceep                = ucp.addVars(systems, periods, years,                  vtype=GRB.CONTINUOUS, lb=0,  name = 'ceep_period')

imports             = ucp.addVars(set(N_To), periods, years,                vtype=GRB.CONTINUOUS, lb=0,  name = 'imports_period')
imports_from        = ucp.addVars(set(N_To), set(N_From), periods, years,   vtype=GRB.CONTINUOUS, lb=0,  name = 'imports_period')
#exports_to    = ucp.addVars(N_From, N_To, periods, years, vtype=GRB.CONTINUOUS, name = 'imports_period')

CO2_total           = ucp.addVars(systems, years,                           vtype=GRB.CONTINUOUS, lb=0,  name = 'CO2_total_elect')
CO2_total_heat      = ucp.addVars(systems, years,                           vtype=GRB.CONTINUOUS, lb=0,  name = 'CO2_total_heat')
CO2_total_industry  = ucp.addVars(systems, years,                           vtype=GRB.CONTINUOUS, lb=0,  name = 'CO2_total_industry')

#FuelCell variables
cap_inv_FC          = ucp.addVars(systems, FC_units, years,                 vtype=GRB.CONTINUOUS, lb=0,  name = 'FC_capacity_Investment')
generation_FC       = ucp.addVars(systems, FC_units , periods, years,       vtype=GRB.CONTINUOUS, lb=0,  name = 'gen_output_FuelCell')


#Hydro Storage variables
storage_level       = ucp.addVars(HydroUnit_system.keys(), periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'Storage_level_Hydro')
sto_out_flow        = ucp.addVars(HydroUnit_system.keys(), periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'sto_out_flow_Hydro')

#Heat variables
heat_gen            = ucp.addVars(CHPMarket_system.keys(), periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'heat_generation')
heat_input          = ucp.addVars(CHPMarket_system.keys(), periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'heat_from_elect_storage_input')
heat_sto_level      = ucp.addVars(CHPMarket_system.keys(), periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'heat_storage_level')

#Industry Heat Demand
Fuel_ind            = ucp.addVars(systems, industry_fuels, periods, years,  vtype = GRB.CONTINUOUS, lb=0,  name = "Industry fuel use")
H2tInd              = ucp.addVars(systems, periods, years,                  vtype = GRB.CONTINUOUS, lb=0,  name = "Industry H2 use")

#Heat pump (power to heat) and traditional boilers
heat_pump_out        = ucp.addVars(systems, HeatPump_units,periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'heat_pump_out')
heat_pump_ind_cap    = ucp.addVars(systems, HeatPump_units, years,          vtype= GRB.CONTINUOUS, lb=0,  name = 'Heat_pump_ind_cap_inv')
heat_pump_ind        = ucp.addVars(systems, HeatPump_units, periods, years, vtype= GRB.CONTINUOUS, lb=0,  name = 'heat_pump_ind')

heat_pump_dh         = ucp.addVars(CHPMarket_system.keys(), HeatPump_units, periods, years, vtype= GRB.CONTINUOUS, lb=0,  name = 'heat_pump_dh')
heat_pump_dh_cap     = ucp.addVars(CHPMarket_system.keys(), HeatPump_units, years,          vtype= GRB.CONTINUOUS, lb=0,  name = 'Heat_pump_df_cap_inv')

#Heat pump for cooling
cooling_pump_dh      = ucp.addVars(CHPMarket_system,HeatPump_units, periods, years,         vtype= GRB.CONTINUOUS, lb=0,  name = 'cooling_pump_dh') 
cooling_pump_ind     = ucp.addVars(systems, HeatPump_units, periods, years,                 vtype= GRB.CONTINUOUS, lb=0,  name = 'cooling_pump_ind')

boiler_dh_generation    = ucp.addVars(Boiler_dh_init_cap.keys(), periods, years,            vtype= GRB.CONTINUOUS, lb=0,  name = 'trad_boilers_Heat_dh')
trad_boiler_dh_cap_inv  = ucp.addVars(Boiler_dh_init_cap.keys(), years,                     vtype= GRB.CONTINUOUS, lb=0,  name = 'capacity_Investment_dh_boiler')
boiler_ind_generation   = ucp.addVars(Thermal_init_cap.keys(), periods, years,              vtype= GRB.CONTINUOUS, lb=0,  name = 'trad_boilers_Heat_ind')
trad_boiler_ind_cap_inv = ucp.addVars(Thermal_init_cap.keys(), years,                       vtype= GRB.CONTINUOUS, lb=0,  name = 'capacity_Investment_ind_boiler')


ResToHeat           = ucp.addVars(systems, periods, years,                  vtype= GRB.CONTINUOUS, lb=0,  name = 'Res_to_Heat')
heat_pump_cap       = ucp.addVars(systems, HeatPump_units, years,           vtype= GRB.CONTINUOUS, lb=0,  name = 'Heat_pump_cap_inv')
heat_pump_sto_soc   = ucp.addVars(systems, HeatPump_units, periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'heatpump_sto_soc')

if NoResToHeatInv:
    no_inv_resToheat        = ucp.addConstrs(heat_pump_cap[region, genco, year]<=0                  for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for year in years)
    no_resToheat            = ucp.addConstrs(ResToHeat[region, period, year]<=0                     for region in systems for period in periods for year in years)
    no_heat_pump            = ucp.addConstrs(heat_pump_out[region, genco,period, year]<=0           for region in systems for genco in HeatPump_units if genco in flexUnit_system[region]  for period in periods for year in years)
    no_heat_pump_ind_cap    = ucp.addConstrs(heat_pump_ind_cap[region, genco, year]<=0              for region in systems for genco in HeatPump_units if genco in flexUnit_system[region]  for year in years) # equation updated
    no_heat_pump_dh_cap     = ucp.addConstrs(heat_pump_dh_cap[region, chp_market, genco, year]<=0   for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for chp_market in chp_units if chp_market in CHPMarket_system_check[region] for year in years) # equation updated
    
    
#EV VARIABLE STORAGE
ev_sto_in           = ucp.addVars(systems,periods, years,                       vtype= GRB.CONTINUOUS, lb=0,  name = 'ev_storage_in')
ev_sto_out          = ucp.addVars(systems,periods, years,                       vtype= GRB.CONTINUOUS, lb=0,  name = 'ev_storage_out')
ev_sto_soc          = ucp.addVars(systems,periods, years,                       vtype= GRB.CONTINUOUS, lb=0,  name = 'ev_sto_soc')

#STATIONARY STORAGE
stat_sto_in         = ucp.addVars(systems, Stat_storage_unit,periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'stat_storage_in')
stat_sto_out        = ucp.addVars(systems, Stat_storage_unit,periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'stat_storage_out')
stat_sto_soc        = ucp.addVars(systems, Stat_storage_unit,periods, years,  vtype= GRB.CONTINUOUS, lb=0,  name = 'stat_sto_soc')
stat_sto_cap_inv    = ucp.addVars(systems, Stat_storage_unit, years,          vtype= GRB.CONTINUOUS, lb=0,  name = 'stat_sto_cap_inv')

#power to H2
power_to_h2             = ucp.addVars(systems,periods, years,                 vtype= GRB.CONTINUOUS, lb=0,  name = 'power_to_h2') 
h2_sto_soc              = ucp.addVars(systems,H2_storage_unit,periods, years, vtype= GRB.CONTINUOUS, lb=0,  name = 'h2_sto_soc')
h2_sto_out              = ucp.addVars(systems,H2_storage_unit,periods, years, vtype= GRB.CONTINUOUS, lb=0,  name = 'h2_storage_out')
h2_sto_max_cap          = ucp.addVars(systems,H2_storage_unit,years,          vtype= GRB.CONTINUOUS, lb=0,  name = 'h2_storage_cap') 
h2_electrolysis_max_cap = ucp.addVars(systems,Elec_h2_units,years,            vtype= GRB.CONTINUOUS, lb=0,  name = 'h2_electrolysis_cap') 
generation_H2           = ucp.addVars(systems,Elec_h2_units,periods,years,    vtype= GRB.CONTINUOUS, lb=0,  name = 'h2_electrolysis_gen') 

######### New Variable (noload) #########

noload_elec             = ucp.addVars(systems, periods, years,                vtype=GRB.CONTINUOUS, lb=0,  name = 'noload_elec')
noload_heat_ind         = ucp.addVars(systems, periods, years,                vtype=GRB.CONTINUOUS, lb=0,  name = 'noload_heat_ind')
noload_heat_dh          = ucp.addVars(systems, chp_units, periods, years,     vtype=GRB.CONTINUOUS, lb=0, name = 'noload_heat_df')


############# New Variable  (Transmition)
transfer_inv                = ucp.addVars(set(N_To), set(N_From), years,               vtype=GRB.CONTINUOUS, name = 'transfer_inv')


##################################################################################################################################################################
##################################################################################################################################################################
##################################################################EQUATIONS#######################################################################################
##################################################################################################################################################################
##################################################################################################################################################################


##################################################################################################################################################################
##################################Respect minimum and maximum output per generator type###########################################################################
##################################################################################################################################################################
max_output       = ucp.addConstrs(generation[region,genco, period, year] <= max_load[genco]*cap_factor[genco]*round(((1-decom_rate[genco])**(max(decom_start_old[genco]-1 ,year - hor_yrs[0])-(decom_start_old[genco]-1))),3) +
                                   cap_inv_cumulative[region,genco, year] *cap_factor[genco] +
                                   cap_inv[region,genco, year]*cap_factor[genco]*round(((1-decom_rate[genco])**(max(decom_start_new[genco]-1 ,0)-(decom_start_new[genco]-1))),3) 
                                                                                                                              for region in systems 
                                                                                                                              for genco  in unit_system[region] if genco in fossil_units
                                                                                                                              for period in periods 
                                                                                                                              for year   in years) #equation updated
max_output_ncre  = ucp.addConstrs((generation[region, genco, period, year] == (max_load[genco]*round(((1-decom_rate[genco])**(max(decom_start_old[genco]-1 ,year - hor_yrs[0])-(decom_start_old[genco]-1))),3) + 
                                                                               cap_inv_cumulative[region, genco, year] +
                                    cap_inv[region, genco, year]*round(((1-decom_rate[genco])**(max(decom_start_new[genco]-1 , 0)-(decom_start_new[genco]-1))),3))*aval_factor_plant[region,genco,period, year])   
                                                                                                                              for region in systems 
                                                                                                                              for genco  in unit_system[region] if genco in nondisp_units
                                                                                                                              for period in periods 
                                                                                                                              for year   in years) #equation updated

max_output_hphs  = ucp.addConstrs((generation[region, genco, period, year] <=  max_load[genco]*cap_factor[genco]*round(((1-decom_rate[genco])**(max(decom_start_old[genco]-1 ,year - hor_yrs[0])-(decom_start_old[genco]-1))),3) +
                                   cap_inv_cumulative[region,genco, year] *cap_factor[genco] +
                                   cap_inv[region, genco, year]*cap_factor[genco]*round(((1-decom_rate[genco])**(max(decom_start_new[genco]-1 ,0)-(decom_start_new[genco]-1))),3)) 
                                                                                                                              for region in systems 
                                                                                                                              for genco  in unit_system[region] if genco in hphs_units
                                                                                                                              for period in periods 
                                                                                                                              for year   in years) #equation updated

max_output_hdam  = ucp.addConstrs((generation[region,genco, period, year] <=  max_load[genco]*cap_factor[genco]*round(((1-decom_rate[genco])**(max(decom_start_old[genco]-1 ,year - hor_yrs[0])-(decom_start_old[genco]-1))),3) +
                                   cap_inv_cumulative[region, genco, year] *cap_factor[genco] +
                                   cap_inv[region,genco, year]*cap_factor[genco]*round(((1-decom_rate[genco])**(max(decom_start_new[genco]-1 ,0)-(decom_start_new[genco]-1))),3))                                    
                                                                                                                              for region in systems 
                                                                                                                              for genco  in unit_system[region] if genco in hdam_units
                                                                                                                              for period in periods 
                                                                                                                              for year   in years) #equation updated

max_output_hror  = ucp.addConstrs((generation[region,genco, period, year] == (max_load[genco]*round(((1-decom_rate[genco])**(max(decom_start_old[genco]-1 ,year - hor_yrs[0])-(decom_start_old[genco]-1))),3) + 
                                                                              cap_inv_cumulative[region, genco, year] +
                                    cap_inv[region,genco, year]*round(((1-decom_rate[genco])**(max(decom_start_new[genco]-1 ,0)-(decom_start_new[genco]-1))),3))*aval_factor_plant[region,genco,period, year])                                   
                                                                                                                              for region in systems 
                                                                                                                              for genco  in unit_system[region] if genco in hror_units
                                                                                                                              for period in periods 
                                                                                                                              for year   in years) #equation updated

max_inv_unit      = ucp.addConstrs((cap_inv[region, genco, year] <= max_inv_period[genco])                                    for year   in years
                                                                                                                              for region in systems 
                                                                                                                              for genco  in unit_system[region])
################################################################################################################################################################    
####################################ELECTRICITY Meet demand#####################################################################################################
################################################################################################################################################################
meet_demand = ucp.addConstrs((    gp.quicksum(generation[region, genco, period, year]                           for genco in unit_system[region] if genco in fossil_units)  + 
                                  gp.quicksum(generation[region, genco, period, year]                           for genco in unit_system[region] if genco in hphs_units)    + 
                                  gp.quicksum(generation[region, genco, period, year]                           for genco in unit_system[region] if genco in hdam_units)    + 
                                  gp.quicksum(generation[region, genco, period, year]                           for genco in unit_system[region] if genco in hror_units)    + 
                                  gp.quicksum(generation[region, genco, period, year]                           for genco in unit_system[region] if genco in nondisp_units) +
                                  gp.quicksum(generation_FC[region, unit, period, year]                         for unit  in FC_units            if unit  in flexUnit_system[region]) +
                                  gp.quicksum(stat_sto_out[region, unit,period, year]*Sta_sto_eff[region, unit] for unit  in Stat_storage_unit   if unit  in flexUnit_system[region]) +
                                  imports[region, period, year] +
                                  ev_Grid_eff*ev_sto_out[region, period, year] +
				  noload_elec[region,period, year]
                                  == 
                                  demand[region, period, year] +
                                  gp.quicksum(stat_sto_in[region,unit,period, year]   for unit in Stat_storage_unit if unit in flexUnit_system[region]) +
                                  gp.quicksum(imports_from[to, region, period, year]  for to in link_from_to[region]) +
                                  ev_sto_in[region,period, year] + 
                                  power_to_h2[region,period, year] +
                                  ResToHeat[region,period, year]  +
                                  ceep[region,period, year]) 
                                  
                             for region in systems 
                             for period in periods 
                             for year in years)

if ceep_limit: ceep_demand = ucp.addConstrs((gp.quicksum(ceep[region, period, year] for period in periods)
                                             <=
                                             ceep_parameter*(gp.quicksum(demand[region, period, year]   for period in periods)+
                                                             gp.quicksum(stat_sto_in[region, unit, period, year] - stat_sto_out[region, unit, period, year]/Sta_sto_eff[region,unit]
                                                                                                                 for unit  in Stat_storage_unit if unit  in flexUnit_system[region] for period in periods)+
                                                             gp.quicksum(ResToHeat[region, period,year]          for period in periods )+
                                                             gp.quicksum(power_to_h2[region, period, year]       for period in periods)+
                                                             gp.quicksum(ev_sto_in[region, period, year] - ev_sto_out[region, period, year]/ev_Grid_eff 
                                                                                                                 for period in periods)))
                                           for region in systems for year in years)

##################################################################################################################################################################
################################################################## IND DEMAND#####################################################################################
##################################################################################################################################################################

ind_demand_meet = ucp.addConstrs((Fuel_ind[region, fuel, period, year] 
                                  <= 
                                 fuel_share_max[region,period,year,fuel]*(Industry_HT_demand[region, period, year] - H2tInd[region, period, year])) 
                                 for region in systems for fuel in industry_fuels for period in periods for year in years )

industry_demand_meet = ucp.addConstrs(gp.quicksum(Fuel_ind[region, fuel, period, year] for fuel in industry_fuels) +
                                      H2tInd[region, period, year] 
                                      == 
                                      Industry_HT_demand[region, period, year] 
                                      for region in systems for period in periods for year in years)

##################################################################################################################################################################
#################################################################### H2 demand and storage########################################################################
##################################################################################################################################################################           
Power_to_h2_c = ucp.addConstrs(gp.quicksum(generation_H2[region, flex_unit, period, year]/H2_eff[region, flex_unit] for flex_unit in Elec_h2_units if flex_unit  in flexUnit_system[region]) 
                             == 
                             power_to_h2[region, period, year]    
                             for region in systems for period in periods for year in years)

h2_electrolysis  = ucp.addConstrs(generation_H2[region, flex_unit, period, year] <= H2_init_cap[region, flex_unit] + h2_electrolysis_max_cap_cumulative[region,flex_unit, year] +
                                  h2_electrolysis_max_cap[region, flex_unit, year] for region in systems for flex_unit in Elec_h2_units if flex_unit in flexUnit_system[region] for period in periods for year in years) #equation updated

h2_storage_soc_0 = ucp.addConstrs(h2_sto_soc[region, sto_unit,1, year]  == 0.0*h2_sto_soc[region, sto_unit, 1, year] - h2_sto_out[region, sto_unit,1, year] +
                                  gp.quicksum(generation_H2[region,flex_unit, 1, year] for flex_unit in Elec_h2_units if flex_unit in flexUnit_system[region])                                                   
                                  for region in systems for sto_unit in H2_storage_unit if sto_unit in flexUnit_system[region] for year in years) 
 
h2_storage_soc   = ucp.addConstrs(h2_sto_soc[region, sto_unit,period, year] == h2_sto_soc[region, sto_unit, period-1, year] - h2_sto_out[region, sto_unit, period, year] +
                                  gp.quicksum(generation_H2[region, flex_unit, period, year] for flex_unit in Elec_h2_units if flex_unit in flexUnit_system[region])                                              
                                  for region in systems for sto_unit in H2_storage_unit if sto_unit in flexUnit_system[region] for period in periods[1:] for year in years)

h2_storage_max   = ucp.addConstrs(h2_sto_soc[region, sto_unit,period, year] <= H2_sto_init[region, sto_unit] + h2_sto_max_cap_cumulative[region,sto_unit,year] +
                                  h2_sto_max_cap[region, sto_unit, year]  for region in systems for sto_unit in H2_storage_unit if sto_unit in flexUnit_system[region] for period in periods  for year in years) #equation updated

h2_storage_min   = ucp.addConstrs(h2_sto_soc[region, sto_unit, period, year] >= 0
                                  for region in systems for sto_unit in H2_storage_unit if sto_unit in flexUnit_system[region] for period in periods  for year in years) #equation updated

h2_storage_last  = ucp.addConstrs(h2_sto_soc[region, sto_unit,len(periods), year] <= 0.2*(H2_sto_init[region, sto_unit] + h2_sto_max_cap_cumulative[region,sto_unit,year] +
                                  h2_sto_max_cap[region, sto_unit, year]) for region in systems for sto_unit in H2_storage_unit if sto_unit in flexUnit_system[region] for year in years) #equation updated

max_output_FCell = ucp.addConstrs((generation_FC[region, genco, period, year] <=  FC_init_cap[region, genco] + cap_inv_FC_cumulative[region, genco, year] + 
                                   cap_inv_FC[region, genco, year] ) for region in systems for genco in FC_units if genco in flexUnit_system[region] for period in periods for year in years) #equation updated

h2_demand        = ucp.addConstrs((gp.quicksum(h2_sto_out[region, genco,period, year] for genco in H2_storage_unit if genco in flexUnit_system[region]) == 
                                   H2_demand[region, period, year] + 
                                   gp.quicksum(generation_FC[region, genco, period, year]/FC_eff[region, genco] for genco in FC_units if genco in flexUnit_system[region]) +
                                   H2tInd[region,period, year])
                                   for region in systems for period in periods for year in years)

max_FC_inv_cap           = ucp.addConstrs(cap_inv_FC[region, flex_unit, year]  <= FC_max_cap[region, flex_unit]/ len(hor_yrs)     for region in systems for flex_unit in FC_units if flex_unit in flexUnit_system[region] for year in years) #equation updated
max_H2_storage_inv_cap   = ucp.addConstrs(h2_sto_max_cap[region, flex_unit, year] <= H2_sto_max_cap[region, flex_unit]/ len(hor_yrs) for region in systems for flex_unit in H2_storage_unit if flex_unit in flexUnit_system[region] for year in years) #equation updated
max_Elec_h2_inv_cap      = ucp.addConstrs(h2_electrolysis_max_cap[region, flex_unit, year]  <= H2_max_cap[region, flex_unit]/ len(hor_yrs)  for region in systems for flex_unit in Elec_h2_units if flex_unit in flexUnit_system[region] for year in years) #equation updated

##################################################################################################################################################################
####################################################################EV VARIABLE STORAGE###########################################################################
##################################################################################################################################################################
ev_storage_soc_0 = ucp.addConstrs(ev_sto_soc[region, 1, year] == 
                                 0.0*ev_sto_max[year] - 
                                 ev_transp_load[1, year]*ev_Demand[region, year] - 
                                 ev_sto_out[region, 1, year] + 
                                 ev_Grid_eff*ev_sto_in[region, 1, year] 
                                 for region in systems for year in years)  

ev_storage_soc   = ucp.addConstrs(ev_sto_soc[region, period, year] == 
                                  ev_sto_soc[region, period-1, year] - 
                                  ev_transp_load[period, year]*ev_Demand[region, year] - 
                                  ev_sto_out[region, period, year]+ 
                                  ev_Grid_eff*ev_sto_in[region, period, year]     
                                  for region in systems for period in periods[1:] for year in years)

ev_storage_max      = ucp.addConstrs(ev_sto_soc[region, period, year] <= ev_sto_max[ year] for region in systems for period in periods for year in years)
ev_storage_min      = ucp.addConstrs(ev_sto_soc[region, period, year] >= ev_sto_min*ev_sto_max[ year] for region in systems for period in periods for year in years)

ev_powerOUT_max     = ucp.addConstrs(ev_sto_out[region, period, year] <= ev_Grid_P_max[year]*ev_availability[ period, year] for region in systems for period in periods for year in years)
ev_powerIN_max      = ucp.addConstrs(ev_sto_in[region, period, year]  <= ev_Grid_P_max[year]*ev_availability[ period, year] for region in systems for period in periods for year in years)

##################################################################################################################################################################
####################################################################STATIOTNARY STORAGE###########################################################################
##################################################################################################################################################################
stat_storage_soc_0 = ucp.addConstrs(stat_sto_soc[region, unit,1, year] == 
                                 0.0*Sta_sto_max_cap[region, unit] -
                                 stat_sto_out[region, unit,1, year] + 
                                 stat_sto_in[region, unit,1, year]*Sta_sto_eff[region, unit]  
                                 for region in systems for unit in Stat_storage_unit if unit in flexUnit_system[region] for year in years )  

stat_storage_soc   = ucp.addConstrs(stat_sto_soc[region, unit,period, year] == 
                                  stat_sto_soc[region, unit,period-1, year] - 
                                  stat_sto_out[region, unit,period, year]+ 
                                  stat_sto_in[region, unit,period, year]*Sta_sto_eff[region, unit]  
                                  for region in systems for period in periods[1:] for year in years for unit in Stat_storage_unit if unit in flexUnit_system[region])

stat_storage_max   = ucp.addConstrs(stat_sto_soc[region, unit,period, year]<= 
                                    Sta_sto_init_cap[region, unit]*StaStoDecomInd_dict[region, year]  + stat_sto_cap_inv_cumulative[region, unit, year] + 
                                    stat_sto_cap_inv[region, unit, year]*round(((1-Sta_sto_decom_rate[region, unit])**(max(Sta_sto_decom_start_new[region, unit]-1 ,0)-(Sta_sto_decom_start_new[region, unit]-1))),3)
                                    for region in systems for unit in Stat_storage_unit for period in periods for year in years) #equation updated

stat_storage_inv_max   = ucp.addConstrs(stat_sto_cap_inv[region, unit, year] <= Sta_sto_max_cap[region, unit]/ len(hor_yrs)   for region in systems for unit in Stat_storage_unit if unit in flexUnit_system[region] for year in years) #equation updated

stat_storage_last_max  = ucp.addConstrs(stat_sto_soc[region, unit, len(periods), year]  <= 0.2*Sta_sto_max_cap[region, unit]  
                                        for region in systems for unit in Stat_storage_unit if unit in flexUnit_system[region] for year in years)

################################################################################################################################################################
####################################################################HEAT PUMP SYSTEM############################################################################
################################################################################################################################################################
if NoResToHeatInv == False:       
    heat_pump_ResGen = ucp.addConstrs((gp.quicksum((heat_pump_dh[region, chp_market, genco, period, year]/HP_COP_period[genco, period, year]+
                                                    cooling_pump_dh[region, chp_market, genco, period, year]/HP_COP_period[genco,period, year])
                                                   for genco in HeatPump_units if genco in flexUnit_system[region]
                                                   for chp_market in chp_units if chp_market in CHPMarket_system_check[region]) +
                                       gp.quicksum(heat_pump_ind[region, genco,period, year]/HP_COP_period[genco,period, year] for genco in HeatPump_units if genco in flexUnit_system[region])
                                       == 
                                       ResToHeat[region, period, year])                                                                                                    
                                      for region in systems for period in periods for year in years)
    
    no_boiler_cooling_DH = ucp.addConstr(gp.quicksum(cooling_pump_dh[region, chp_market,'electric_boiler',period, year] 
                                                     for region in systems for genco in HeatPump_units for chp_market in  CHPMarket_system_check[region] for period in periods for year in years) 
                                         == 0)
    no_boiler_cooling_ind = ucp.addConstr(gp.quicksum(cooling_pump_ind[region, 'electric_boiler', period, year] for region in systems for period in periods for year in years) == 0)

    
    heat_pump_dh_max = ucp.addConstrs(heat_pump_dh[region, chp_market, genco, period, year] + cooling_pump_dh[region,chp_market,genco,period, year]  <= 
                                      HP_Boiler_dh_init_cap[region, chp_market,genco]*HeatPumpDecomDH_dict[region,year]  + heat_pump_dh_cap_cumulative[region, chp_market,genco,  year] +
                                   heat_pump_dh_cap[region, chp_market, genco, year]*round(((1-HP_decom_rate[region, genco])**(max(HP_decom_start_new[region, genco]-1,0)-(HP_decom_start_new[region, genco]-1))),3)       
                                  for region in systems for genco in HeatPump_units if genco in flexUnit_system[region]
                                  for chp_market in CHPMarket_system_check[region] for period in periods for year in years) #equation updated
    
    heat_pump_ind_max = ucp.addConstrs(heat_pump_ind[region, genco,period, year] <= HP_ind_init_cap[region, genco]*HeatPumpDecomInd_dict[region, year] +
                                       heat_pump_ind_cap_cumulative[region, genco, year] + 
                                   heat_pump_ind_cap[region, genco, year]*round(((1-HP_decom_rate[region, genco])**(max(HP_decom_start_new[region, genco]-1,0)-(HP_decom_start_new[region, genco]-1))),3)               
                                   for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for period in periods for year in years) #equation updated
    
    heat_pump_soc     = ucp.addConstrs((heat_pump_sto_soc[region, genco,period, year] ==
                                        heat_pump_sto_soc[region, genco,period - 1, year] + 
                                        heat_pump_ind[region, genco,period, year] - 
                                        heat_pump_out[region, genco,period, year] - 
                                        cooling_pump_ind[region, genco,period, year])
                                       for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for period in periods[1:] for year in years)
    
    heat_pump_soc_0   = ucp.addConstrs((heat_pump_sto_soc[region, genco,1, year] ==
                                        heat_pump_ind[region, genco,1, year] - 
                                        heat_pump_out[region, genco,1, year]- 
                                        cooling_pump_ind[region, genco,1, year])
                                       for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for year in years)
    
    heat_pump_soc_max  = ucp.addConstrs((heat_pump_sto_soc[region, genco,period, year]       <= HP_sto_init[region, genco])         for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for period in periods for year in years)
    heat_pump_soc_last = ucp.addConstrs((heat_pump_sto_soc[region, genco,len(periods), year] <= 0.2*HP_sto_init[region, genco])     for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for year in years)

    boiler_max_prod_dh = ucp.addConstrs(boiler_dh_generation[region,chp_market,boiler,period,year] <=
                                        HP_Boiler_dh_init_cap[region,chp_market,boiler]*HeatPumpDecomDH_dict[region,year]  + trad_boiler_dh_cap_inv_cumulative [region, chp_market, boiler, year] +
                                        trad_boiler_dh_cap_inv[region,chp_market,boiler,year]*round(((1-Boiler_decom_rate[region,boiler])**(max(Boiler_decom_start_new[region,boiler]-1,0)-(Boiler_decom_start_new[region,boiler]-1))),3) 
                                        for region in systems for boiler in thermal_units for chp_market in CHPMarket_system_check[region]  for period in periods for year in years) #equation updated
   
    boiler_max_prod_ind = ucp.addConstrs(boiler_ind_generation[region,boiler,period,year] <= 
                                        Thermal_init_cap[region,boiler]*ThermalDecomInd_dict[region,year]  + trad_boiler_ind_cap_inv_cumulative [region,boiler, year] + 
                                        trad_boiler_ind_cap_inv[region,boiler,year]*round(((1-Boiler_decom_rate[region,boiler])**(max(Boiler_decom_start_new[region,boiler]-1,0)-(Boiler_decom_start_new[region,boiler]-1))),3)                                           
                                        for region in systems for boiler in thermal_units for period in periods for year in years) #equation updated
    
    max_boiler_cap_inv  = ucp.addConstrs(trad_boiler_ind_cap_inv[region,boiler,year] + 
                                         gp.quicksum(trad_boiler_dh_cap_inv[region,chp_market,boiler,year] for chp_market in CHPMarket_system_check[region])
                                         <= Thermal_max_cap[region,boiler]/ len(hor_yrs) for region in systems for boiler in thermal_units for year in years) #equation updated
    
    max_HP_cap_inv  = ucp.addConstrs(heat_pump_ind_cap[region,hpUnit,year]  +
                                          gp.quicksum(heat_pump_dh_cap[region,chp_market,hpUnit,year] for chp_market in CHPMarket_system_check[region])
                                          <= HP_max_cap[region,hpUnit]/ len(hor_yrs) 
                                          for region in systems for hpUnit in HeatPump_units if hpUnit in flexUnit_system[region] for year in years) #equation updated
            
################################################################################################################################################################
#################################################### CHP generation - storage constraints#######################################################################
################################################################################################################################################################

max_heat_production     = ucp.addConstrs((heat_input[region, genco, period, year]*CHPPowerToHeat[genco] <= generation[region, genco, period, year])  
                                         for region in systems for genco in CHPMarket_system_check[region] for period in periods for year in years)

gen_heat_extraction_max = ucp.addConstrs((generation[region, genco, period, year] <= 
                                          max_load[genco]*cap_factor[genco]*round(((1-decom_rate[genco])**(max(decom_start_old[genco]-1 ,year-hor_yrs[0])-(decom_start_old[genco]-1))),3) +
                                          cap_inv_cumulative[region,genco, year] *cap_factor[genco] +
                                          cap_inv[region, genco, year]*cap_factor[genco]*round(((1-decom_rate[genco])**(max(decom_start_new[genco]-1 ,0)-(decom_start_new[genco]-1))),3) 
                                          - heat_input[region, genco, period, year]*CHPPowerLossFactor[genco])  
                                         for region in systems for genco in CHPMarket_system_check[region] for period in periods for year in years) #equation updated

heat_storage_level0     = ucp.addConstrs((heat_sto_level[region, genco, 1, year] == 0.5*STOCapacity_heat[genco] +
                                       heat_input[region, genco, 1, year] - heat_gen[region, genco, 1, year])      
                                         for region in systems for genco in CHPMarket_system_check[region] for year in years) 

heat_storage_level      = ucp.addConstrs((heat_sto_level[region, genco, period, year] == heat_sto_level[region, genco, period-1, year] +
                                      heat_input[region, genco, period, year] +
                                      gp.quicksum(heat_pump_dh[region, genco, HPUnit,period, year] for HPUnit in HeatPump_units if HPUnit in flexUnit_system[region] )+
                                      gp.quicksum(boiler_dh_generation[region, genco, boiler, period,year] for boiler in thermal_units) -
                                      heat_gen[region, genco, period, year])                                                                 
                                      for region in systems for genco in CHPMarket_system_check[region] for period in periods[1:] for year in years)

max_heat_sto_level      = ucp.addConstrs((heat_sto_level[region, genco, period, year] <= STOCapacity_heat[genco])  
                                         for region in systems for genco in CHPMarket_system_check[region] for period in periods for year in years)

max_heat_gen            = ucp.addConstrs((heat_input[region, genco, period, year] <= CHPMaxHeat[genco])     
                                        for region in systems for genco in CHPMarket_system_check[region] for period in periods for year in years)


################################################################################################################################################################
##################################################Meet Cooling and Heat demand #################################################################################
################################################################################################################################################################
meet_heat_demand        = ucp.addConstrs((heat_gen[region, genco, period, year]  + noload_heat_dh[region, genco, period, year] == heat_demand_DH_indv[genco,period, year])
                                        for region in systems for genco in CHPMarket_system_check[region] for period in periods for year in years)

meet_heat_demand_gen    = ucp.addConstrs((gp.quicksum(heat_pump_out[region, genco,period, year] for genco in HeatPump_units) +
                                          gp.quicksum(boiler_ind_generation[region, boiler,period,year] for boiler in thermal_units) +
					  noload_heat_ind[region, period, year] ==
                                          heat_demand_individual[region, period, year])
                                         for region in systems for period in periods for year in years)

meet_cooling_demand_gen = ucp.addConstrs((gp.quicksum(cooling_pump_ind[region, genco,period, year] for genco in HeatPump_units if genco in flexUnit_system[region]) 
                                          ==
                                          cooling_demand_individual[region, period, year])
                                         for region in systems for period in periods for year in years) 

meet_cooling_demand_dh = ucp.addConstrs((gp.quicksum(cooling_pump_dh[region, chp_market, genco, period, year] for genco in HeatPump_units if genco in flexUnit_system[region]) ==
                                          cooling_demand_DH_indv[chp_market,period, year])
                                         for region in systems for chp_market in CHPMarket_system_check[region] for period in periods for year in years ) 



################################################################################################################################################################
##################################################Storage Hydro Dam constraints#################################################################################
################################################################################################################################################################
if hydro_storage:
    
    storage_level_min    = ucp.addConstrs((storage_level[region, genco, period, year] >= 0.5*hdam_max_storage[region, genco])  
                                          for region in systems for genco in HDAM_system_check[region] for period in periods for year in years) 
    
    
    storage_level_max    = ucp.addConstrs((storage_level[region, genco, period, year] <= hdam_max_storage[region, genco]) 
                                          for region in systems for genco in HDAM_system_check[region] for period in periods for year in years) 
    
    storage_level_end    = ucp.addConstrs((storage_level[region, genco, len(periods), year] >= 0.5*hdam_max_storage[region, genco])       
                                          for region in systems for genco in HDAM_system_check[region] for year in years)
    
    storage_level_cap_0  = ucp.addConstrs((storage_level[region, genco, 1, year]      == 0.5*hdam_max_storage[region, genco] +
                                           hdam_inflow[genco, 1, year]*max_load[genco]*hdam_efficiency[region, genco] -
                                           generation[region, genco, 1, year]/hdam_efficiency[region, genco]- 
                                           sto_out_flow[region, genco, 1, year])                                                  
                                          for region in systems for genco in HDAM_system_check[region] for year in years) 
    
    storage_level_balance= ucp.addConstrs((storage_level[region, genco, period, year] == storage_level[region, genco, period-1, year] +
                                           hdam_inflow[genco, period, year]*max_load[genco]*hdam_efficiency[region, genco] -
                                           generation[region, genco, period, year]/hdam_efficiency[region, genco] - 
                                           sto_out_flow[region, genco, period, year])                                             
                                          for region in systems for genco in HDAM_system_check[region] for period in periods[1:] for year in years) 
    
    hdam_storage_gen_cap = ucp.addConstrs((generation[region, genco, period, year]/hdam_efficiency[region, genco] +
                                           sto_out_flow[region, genco, period, year] <= 
                                           storage_level[region, genco, period, year] +
                                           hdam_inflow[genco, period, year]*max_load[genco]*hdam_efficiency[region, genco])       
                                          for region in systems for genco in HDAM_system_check[region] for period in periods for year in years)

################################################################################################################################################################         
#################################################Storage Hydro HPHS constraints################################################################################# 
################################################################################################################################################################
if hydro_storage:
    
    hphs_storage_level_min    = ucp.addConstrs((storage_level[region, genco, period, year] >= 0.5*hphs_max_storage[region,genco])        
                                              for region in systems for genco in HPHS_system_check[region] for period in periods for year in years)
    hphs_storage_level_max    = ucp.addConstrs((storage_level[region, genco, period, year] <= hphs_max_storage[region, genco])            
                                               for region in systems for genco in HPHS_system_check[region] for period in periods for year in years)
    hphs_storage_level_end    = ucp.addConstrs((storage_level[region, genco, len(periods), year] >= 0.5*hphs_max_storage[region, genco])  
                                               for region in systems for genco in HPHS_system_check[region] for year in years) # equation updated

    hphs_storage_level_cap_0  = ucp.addConstrs((storage_level[region, genco, 1, year]      == 0.5*hphs_max_storage[region,genco] +
                                                hphs_inflow[genco, 1, year]*max_load[genco]*hphs_efficiency[region,genco] -
                                                generation[region,genco, 1, year]/hphs_efficiency[region,genco]-
                                                sto_out_flow[region,genco, 1, year])                                             
                                               for region in systems for genco in HPHS_system_check[region] for year in years) # equation updated
    
    hphs_storage_level_period = ucp.addConstrs((storage_level[region,genco, period, year] == storage_level[region,genco, period-1, year] +
                                                hphs_inflow[genco, period, year]*max_load[genco]*hphs_efficiency[region,genco] -
                                                generation[region,genco, period, year]/hphs_efficiency[region,genco]-
                                                sto_out_flow[region,genco, period, year])                                        
                                               for region in systems for genco in HPHS_system_check[region] for period in periods[1:] for year in years)
    
    hphs_storage_gen_cap      = ucp.addConstrs((generation[region,genco, period, year]/hphs_efficiency[region,genco] +
                                                sto_out_flow[region,genco, period, year] <= 
                                                storage_level[region,genco, period, year] +
                                                hphs_inflow[genco, period, year]*max_load[genco]*hphs_efficiency[region,genco])  
                                               for region in systems for genco in HPHS_system_check[region] for period in periods for year in years)

################################################################################################################################################################    
#Rump up constraints
rump_up   = ucp.addConstrs(generation[region,genco, period, year] <= generation[region, genco, period-1, year] + 
                           ramp_up_rate[genco]*(max_load[genco]*round(((1-decom_rate[genco])**(max(decom_start_old[genco]-1 ,year- hor_yrs[0])-(decom_start_old[genco]-1))),3) +
                                                cap_inv_cumulative[region,genco, year] + 
                                                cap_inv[region, genco, year]*round(((1-decom_rate[genco])**(max(decom_start_new[genco]-1 ,0)-(decom_start_new[genco]-1))),3)) 
                          for region in systems for genco in unit_system[region] if genco in disp_units for period in periods[1:] for year in years) #equation updated



rump_down = ucp.addConstrs(generation[region, genco, period, year] >= generation[region, genco, period-1, year] - 
                           ramp_down_rate[genco]*(max_load[genco]*round(((1-decom_rate[genco])**(max(decom_start_old[genco]-1 ,year- hor_yrs[0])-(decom_start_old[genco]-1))),3) + 
                                                  cap_inv_cumulative[region,genco, year] + 
                                                  cap_inv[region, genco, year]*round(((1-decom_rate[genco])**(max(decom_start_new[genco]-1 ,0)-(decom_start_new[genco]-1))),3))  
                           for region in systems for genco in unit_system[region] if genco in disp_units for period in periods[1:] for year in years) #equation updated


"""
import_to = ucp.addConstrs(imports[to, period, year] ==  gp.quicksum(imports_from[to, n_from, period, year] for n_from in set(N_From) if n_from in link_check[to])   
                           for to in set(N_To) for period in periods for year in years)

import_lim= ucp.addConstrs(imports_from[to, n_from, period, year] <= transfer_limits[to, n_from]   for to in set(N_To) for n_from in set(N_From) if n_from in link_check[to] for period in periods for year in years)

rump_up   = ucp.addConstrs(imports_from[to, n_from, period, year] <= imports_from[to, n_from, period-1, year]*(1 + 0.2)  
                           for to in set(N_To) for n_from in set(N_From) if n_from in link_check[to] for period in periods[1:] for year in years)
rump_down = ucp.addConstrs(imports_from[to, n_from, period, year] >= imports_from[to, n_from, period-1, year]*(1 - 0.2)  
                           for to in set(N_To) for n_from in set(N_From) if n_from in link_check[to] for period in periods[1:] for year in years) 
"""

if rps_inv & rps_inv_National:
    
    rps       = ucp.addConstrs((gp.quicksum(generation[region, genco, period, year] for genco  in unit_system[region] if genco in nondisp_units for period in periods) +
                                gp.quicksum(generation[region, genco, period, year] for genco  in unit_system[region] if genco in biomass_units for period in periods)+
                                gp.quicksum(generation[region, genco, period, year] for genco  in unit_system[region] if genco in hydro_units   for period in periods)
                               >=
                               rps_dict[region, year]*(gp.quicksum(generation[region, genco, period, year]   for genco  in unit_system[region] if genco in fossil_units for period in periods) + 
                                  gp.quicksum(generation[region, genco, period, year]           for genco  in unit_system[region] if genco in hphs_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for genco  in unit_system[region] if genco in hdam_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for genco  in unit_system[region] if genco in hror_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for genco  in unit_system[region] if genco in nondisp_units for period in periods)   +
                                  gp.quicksum(imports[region, period, year]                     for period in periods))) 
                               for region in systems for year   in years)
    
    rps_National = ucp.addConstrs((gp.quicksum(generation[region, genco, period, year] for region in systems for genco  in unit_system[region] if genco in nondisp_units for period in periods) +
                                gp.quicksum(generation[region, genco, period, year] for region in systems for genco  in unit_system[region] if genco in biomass_units for period in periods )+
                                gp.quicksum(generation[region, genco, period, year] for region in systems for genco  in unit_system[region] if genco in hydro_units   for period in periods )
                               >=
                               rps_dict_National[year]*(gp.quicksum(generation[region, genco, period, year]   for region in systems for genco  in unit_system[region] if genco in fossil_units for period in periods ) + 
                                  gp.quicksum(generation[region, genco, period, year]           for region in systems for genco  in unit_system[region] if genco in hphs_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for region in systems for genco  in unit_system[region] if genco in hdam_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for region in systems for genco  in unit_system[region] if genco in hror_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for region in systems for genco  in unit_system[region] if genco in nondisp_units for period in periods))) 
                                for year   in years)


if rps_inv & (rps_inv_National == False):
    
    rps       = ucp.addConstrs((gp.quicksum(generation[region, genco, period, year] for genco  in unit_system[region] if genco in nondisp_units for period in periods) +
                                gp.quicksum(generation[region, genco, period, year] for genco  in unit_system[region] if genco in biomass_units for period in periods)+
                                gp.quicksum(generation[region, genco, period, year] for genco  in unit_system[region] if genco in hydro_units   for period in periods)
                               >=
                               rps_dict[region, year]*(gp.quicksum(generation[region, genco, period, year]   for genco  in unit_system[region] if genco in fossil_units for period in periods) + 
                                  gp.quicksum(generation[region, genco, period, year]           for genco  in unit_system[region] if genco in hphs_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for genco  in unit_system[region] if genco in hdam_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for genco  in unit_system[region] if genco in hror_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for genco  in unit_system[region] if genco in nondisp_units for period in periods)   +
                                  gp.quicksum(imports[region, period, year]                     for period in periods))) 
                               for region in systems for year   in years)
    
if (rps_inv == False) & rps_inv_National:
    
    rps_National = ucp.addConstrs((gp.quicksum(generation[region, genco, period, year] for region in systems for genco  in unit_system[region] if genco in nondisp_units for period in periods) +
                                gp.quicksum(generation[region, genco, period, year] for region in systems for genco  in unit_system[region] if genco in biomass_units for period in periods )+
                                gp.quicksum(generation[region, genco, period, year] for region in systems for genco  in unit_system[region] if genco in hydro_units   for period in periods )
                               >=
                               rps_dict_National[year]*(gp.quicksum(generation[region, genco, period, year]   for region in systems for genco  in unit_system[region] if genco in fossil_units for period in periods ) + 
                                  gp.quicksum(generation[region, genco, period, year]           for region in systems for genco  in unit_system[region] if genco in hphs_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for region in systems for genco  in unit_system[region] if genco in hdam_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for region in systems for genco  in unit_system[region] if genco in hror_units    for period in periods)   + 
                                  gp.quicksum(generation[region, genco, period, year]           for region in systems for genco  in unit_system[region] if genco in nondisp_units for period in periods))) 
                                for year   in years)
                         
if not res_inv:
    
    non_inv  = ucp.addConstrs((gp.quicksum(cap_inv[region, genco, year] for region in systems for genco  in unit_system[region] if genco in nondisp_units) + 
                               gp.quicksum(cap_inv_FC[region, genco, year] for region in systems for genco in FC_units if genco in flexUnit_system[region]) == 0) for year in years)
    
        
CO2_emissions_power = ucp.addConstrs(gp.quicksum(CO2_factor[genco]*generation[region,genco,period, year] for genco  in unit_system[region] if genco in fossil_units for period in periods) ==
                                         CO2_total[region, year]                                                                                                        
                                        for region in systems for year in years)


CO2_emissions_heat = ucp.addConstrs(gp.quicksum(Thermal_CO2[region, genco]*boiler_ind_generation[region, genco,period, year] for genco in thermal_units for period in periods) +
                                         gp.quicksum(Thermal_CO2[region, genco]*boiler_dh_generation[region, chp_market, genco,period,year] 
                                                     for genco in thermal_units for chp_market in CHPMarket_system_check[region] for period in periods) 
                                         ==
                                         CO2_total_heat[region, year]                                                                                                   
                                         for region in systems for year in years)


CO2_emissions_industry = ucp.addConstrs(gp.quicksum(Fuel_CO2[region, fuel]*Fuel_ind[region, fuel, period, year] for fuel in industry_fuels for period in periods) ==
                                        CO2_total_industry[region, year]                                                                                                        
                                        for region in systems for year in years)


####### equation updated (Carbon Limits)

if carbonLimit & carbonLimit_National:

    CO2_emissions_limit = ucp.addConstrs( CO2_total[region, year] + CO2_total_heat[region, year] + CO2_total_industry[region, year]   <= CO2_Limit_dict[region, year] for region in systems for year in years)
    CO2_emissions_limit_National = ucp.addConstrs( gp.quicksum(CO2_total[region, year] + CO2_total_heat[region, year] + CO2_total_industry[region, year] for region in systems)   <= CO2_dict_National[year]  for year in years)

    
if carbonLimit & (carbonLimit_National == False):
    
    CO2_emissions_limit = ucp.addConstrs( CO2_total[region, year] + CO2_total_heat[region, year] + CO2_total_industry[region, year]   <= CO2_Limit_dict[region, year] for region in systems for year in years)

if (carbonLimit == False) & carbonLimit_National:
    
    CO2_emissions_limit_National = ucp.addConstrs( gp.quicksum(CO2_total[region, year] + CO2_total_heat[region, year] + CO2_total_industry[region, year] for region in systems)   <= CO2_dict_National[year]  for year in years)



if Transmission_Inv == False:
    
    No_Transfer  = ucp.addConstrs(transfer_inv[to, n_from, year] <= 0   for to in set(N_To) for n_from in set(N_From) if n_from in link_check[to] for year in years)


import_to = ucp.addConstrs(imports[to, period, year] ==  gp.quicksum(imports_from[to, n_from, period, year] for n_from in set(N_From) if n_from in link_check[to])   
                           for to in set(N_To) for period in periods for year in years)

import_lim =  ucp.addConstrs(imports_from[to, n_from, period, year] <= transfer_limits[to, n_from] + transfer_inv_cumulative[to, n_from, year] + transfer_inv[to, n_from, year]                             
                            for to in set(N_To) for n_from in set(N_From) if n_from in link_check[to] for period in periods for year in years)

import_Sim = ucp.addConstrs(transfer_inv[to, n_from, year] ==  transfer_inv[n_from, to, year] for to in set(N_To) for n_from in set(N_From) if n_from in link_check[to] for year in years)



####################################################################################################################################
#Rump cost constraint
ramp_up_cost = ucp.addConstrs((rampup_cost[region, genco, period, year] >=
                                     ramp_cost[genco]*(generation[region, genco, period, year]-generation[region, genco, period-1, year]))  
                             for region in systems for genco  in unit_system[region] if genco in disp_units for period in periods[1:] for year in years)

ramp_down_cost = ucp.addConstrs((rampdown_cost[region, genco, period, year] >= 
                                     ramp_cost[genco]*(-generation[region, genco, period, year]+generation[region, genco, period-1, year])) 
                                for region in systems for genco  in unit_system[region] if genco in disp_units for period in periods[1:] for year in years)
#####################################################################################################################################
import_cost        = gp.quicksum(npv_dict[region,year]*imports[region,period, year]*Import_Price*(1+Imp_price_inc/100)**(year-hor_yrs[0]) for region in systems for period in periods for year in years)
# Objective: minimize total cost
Fossil_hydro       = disp_units + hydro_units
per_mw             = gp.quicksum(npv_dict[region,year]*var_cost[genco,period, year]*generation[region, genco, period, year]      for region in systems for genco in unit_system[region] if genco in units for period in periods for year in years)
ramp_up_cost_var   = gp.quicksum(npv_dict[region,year]*rampup_cost[region, genco, period, year]                                  for region in systems for genco in unit_system[region] if genco in disp_units for period in periods[1:] for year in years)
ramp_down_cost_var = gp.quicksum(npv_dict[region,year]*rampdown_cost[region, genco, period, year]                                for region in systems for genco in unit_system[region] if genco in disp_units for period in periods[1:] for year in years)
inv_cost_solar     = gp.quicksum(npv_dict[region,year]*cap_inv[region, genco, year]*cap_inv_cost[genco]*TechChangeSolar_dict[region,year] for region in systems for genco in unit_system[region] if genco in solar_units for year in years)
inv_cost_wind      = gp.quicksum(npv_dict[region,year]*cap_inv[region, genco, year]*cap_inv_cost[genco]*TechChangeWind_dict[region,year] for region in systems for genco in unit_system[region] if genco in wind_units for year in years) # equation updated
inv_cost_fossil    = gp.quicksum(npv_dict[region,year]*cap_inv[region, genco, year]*cap_inv_cost[genco]                          for region in systems for genco in unit_system[region] if genco in Fossil_hydro for year in years)
inv_cost_FuelCell  = gp.quicksum(npv_dict[region,year]*cap_inv_FC[region, genco, year]*FC_cap_costs_years[region,genco, year]    for region in systems for genco in FC_units if genco in flexUnit_system[region] for year in years)
per_mw_FC          = gp.quicksum(npv_dict[region,year]*FC_var_cost[region,genco]*generation_FC[region, genco, period, year]      for region in systems for genco in FC_units if genco in flexUnit_system[region] for period in periods for year in years)
heat_pump_cap_cost = (gp.quicksum(npv_dict[region,year]*heat_pump_ind_cap[region,genco, year]*HP_cap_costs_years[region, genco, year]   
                                  for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for year in years) + 
                      gp.quicksum(npv_dict[region,year]*heat_pump_dh_cap[region,chp_market,genco, year]*HP_cap_costs_years[region,genco, year]   
                                  for region in systems 
                                  for genco in HeatPump_units if genco in flexUnit_system[region]
                                  for chp_market in chp_units if chp_market in CHPMarket_system_check[region]
                                  for year in years))
ResToHeat_cost     = (gp.quicksum(npv_dict[region,year]*heat_pump_ind[region,genco,period, year]*HP_var_cost[region,genco]            
                                  for region in systems for genco in HeatPump_units if genco in flexUnit_system[region] for period in periods for year in years) +
                      gp.quicksum(npv_dict[region,year]*heat_pump_dh[region,chp_market,genco,period, year]*HP_var_cost[region,genco]  
                                  for region in systems 
                                  for genco in HeatPump_units if genco in flexUnit_system[region]
                                  for chp_market in chp_units if chp_market in CHPMarket_system_check[region]
                                  for period in periods for year in years))
boiler_gen_cost    = (gp.quicksum(npv_dict[region,year]*boiler_ind_generation[region,genco,period, year]*heat_var_cost[region, genco,period, year]    
                                  for region in systems for genco in thermal_units for period in periods for year in years) +
                     gp.quicksum(npv_dict[region,year]*boiler_dh_generation[region,chp_market,genco,period,year]*heat_var_cost[region,genco,period, year]  
                                 for region in systems
                                 for genco in thermal_units 
                                 for chp_market in chp_units if chp_market in CHPMarket_system_check[region]
                                 for period in periods for year in years))
inv_cost_boiler    = (gp.quicksum(npv_dict[region,year]*trad_boiler_ind_cap_inv[region, genco, year]*boiler_cap_costs_years[region,genco,year]   
                                  for region in systems for genco in thermal_units for year in years) +
                     gp.quicksum(npv_dict[region,year]*trad_boiler_dh_cap_inv[region, chp_market,genco,year]*boiler_cap_costs_years[region,genco,year]      
                                 for region in systems 
                                 for genco in thermal_units 
                                 for chp_market in chp_units if chp_market in CHPMarket_system_check[region]
                                 for year in years))
industry_fuel_cost = gp.quicksum(npv_dict[region,year]*Fuel_ind[region, fuel, period, year]*industry_fuels_price[period,year,fuel]                 for region in systems for period in periods for year in years for fuel in industry_fuels) 
CO2_cost_industry  = gp.quicksum(npv_dict[region,year]*Carbon_price_dict[region, year]*Fuel_CO2[region, fuel]*Fuel_ind[region, fuel, period, year] for region in systems for period in periods for year in years for fuel in industry_fuels)
h2_storage_cost    = gp.quicksum(npv_dict[region,year]*h2_sto_max_cap[region,genco,year]*H2sto_costs_years[region,genco, year]                     for region in systems for genco in H2_storage_unit if genco in flexUnit_system[region] for year in years) 
h2_CAPEX_cost      = gp.quicksum(npv_dict[region,year]*h2_electrolysis_max_cap[region,genco,year]*Elec_cap_costs_years[region,genco, year]         for region in systems  for genco in Elec_h2_units  if genco in flexUnit_system[region] for year in years) 
h2_OPEX_cost       = gp.quicksum(npv_dict[region,year]*generation_H2[region,genco,period,year]*H2_var_cost[region,genco]                           for region in systems  for genco in Elec_h2_units  if genco in flexUnit_system[region] for period in periods for year in years) 
evToPowert_cost    = gp.quicksum(npv_dict[region,year]*ev_sto_out[region,period, year]*V2G_cost                                                    for region in systems for period in periods for year in years) 
statToPowert_cost  = gp.quicksum(npv_dict[region,year]*(stat_sto_out[region,unit,period, year]+stat_sto_in[region,unit,period, year])*Sta_sto_var_cost[region,unit]  for region in systems for unit in Stat_storage_unit if unit in flexUnit_system[region] for period in periods for year in years) 
statCapInvCost     = gp.quicksum(npv_dict[region,year]*stat_sto_cap_inv[region, unit, year]*battery_costs_years[region, unit,year]                 for region in systems for unit in Stat_storage_unit if unit in flexUnit_system[region] for year in years)           
CO2_emissions_cost = gp.quicksum(npv_dict[region,year]*Carbon_price_dict[region,year]*CO2_factor[genco]*generation[region,genco,period, year]      for region in systems for genco in unit_system[region] if genco in fossil_units for period in periods for year in years)
#spill_cost         = gp.quicksum(NPV[year]*sto_out_flow[genco,period, year]*450                                     for genco in hydro_storage_units for period in periods for year in years) 
#ceep_cost          = gp.quicksum(NPV[year]*ceep[period, year]*450                                                   for period in periods for year in years)   


no_load_cost       = gp.quicksum(npv_dict[region,year]*(noload_elec[region,period, year] + noload_heat_ind[region, period, year])*LostLoad_Cost*(1+Imp_price_inc/100)**(year-hor_yrs[0])   for region in systems for period in periods for year in years)  

no_load_cost_dh    =  gp.quicksum(npv_dict[region,year]*noload_heat_dh[region, chp_market,period, year]*LostLoad_Cost*(1+Imp_price_inc/100)**(year-hor_yrs[0])                           for region in systems for chp_market in chp_units for period in periods for year in years)

trans_cost         = gp.quicksum(npv_dict[region,year]*Transmission_Cost*transfer_inv[region,n_from,year] for region in systems for n_from in set(N_From) if n_from in link_check[region] for year in years) # equation updated

ucp.setObjective(    (per_mw 
                      + import_cost 
                      + inv_cost_wind + inv_cost_solar
                      + inv_cost_fossil
                      + ramp_up_cost_var 
                      + ramp_down_cost_var
                      + heat_pump_cap_cost
                      + ResToHeat_cost
                      + boiler_gen_cost
                      + inv_cost_boiler
                      + CO2_emissions_cost
                      + CO2_cost_industry # we are missing CO2 DH/IND heating cost
                      + evToPowert_cost
                      + statToPowert_cost
                      + statCapInvCost
                      + h2_storage_cost
                      + h2_CAPEX_cost
                      + h2_OPEX_cost 
                      + inv_cost_FuelCell 
                      + per_mw_FC  
                      + industry_fuel_cost
                      + no_load_cost
                      + no_load_cost_dh
                      + trans_cost
                      #+ spill_cost + ceep_cost
                      )/1,GRB.MINIMIZE)


ucp.Params.Method  = 3 # Concurrent: Several methods and chooses the one that finishes faster (higher memory usage) 
#ucp.Params.Method    = 2 # Barrier: Faster but possible approximate results (less than 1% deviation from optimal solution)  
ucp.Params.Crossover = 0  
ucp.Params.ScaleFlag = 3
ucp.Params.presolve  = 2   
ucp.optimize() 
#print('*****************************')
#print('*******MODEL SOLVED**********')
#print('*****************************')

if ucp.Status == 2:
    print('******************************************************')
    print('*******MODEL SOLVED - Optimal solution found**********')
    print('******************************************************')
    
if ucp.Status == 13 :
    print('**********************************************')
    print('*******MODEL SOLVED - solution found**********')
    print('**********************************************')
    
if ucp.Status == 3:
    print('******************************************************')
    print('*******MODEL Is INFEASIBLE - Check input data*********')
    print('******************************************************')
    sys.exit()
    
if ucp.Status == 12 :
    print('*****************************************************************')
    print('*******MODEL with numeric issues - Try scaling input data********')
    print('*****************************************************************')
    sys.exit()
    
if ucp.Status != 13 and ucp.Status != 2 and ucp.Status != 3:
    print('*********************************************************************')
    print('*******MODEL infeasible, unbounded, or numeric issues found**********')
    print('*********************************************************************')
    sys.exit()

