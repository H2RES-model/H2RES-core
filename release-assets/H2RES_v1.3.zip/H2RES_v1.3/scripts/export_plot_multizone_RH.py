# -*- coding: utf-8 -*-
"""
Export and plot results for MULTI-ZONE Rolling Horizon runs.

Assume the following globals already exist in the workspace
(from modeling_approaches.py + Build_model.py):

- systems: list of region names (e.g. ['North', 'Center', 'South'])
- years, periods
- scen: scenario name (string)
- save_csv: bool

Dictionaries with results indexed as:
    generation_results[region, unit, period, year]
    imports_from_results[to, from, period, year]
    noload_elec_results[region, period, year]
    storage_level_results[region, unit, period, year]
    Fuel_ind_results[region, fuel, period, year]
    H2tInd_results[region, period, year]
    CO2_total_results[region, year]
    CO2_total_heat_results[region, year]
    CO2_total_industry_results[region, year]

And sets/lists:
    unit_system[region]
    hydro_storage_units
    industry_fuels
    demand_sectors

Also assume a dataframe df (or flex_tech_df) with at least:
    ['unit_name', 'system', 'fuel_type'] or ['unit_name', 'system', 'fuel']
"""

import os
import shutil
import numpy as np
import pandas as pd
from collections import defaultdict
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

plt.rcParams['figure.dpi'] = 150

# ====================================================================================
# 0. Preparar carpeta de resultados
# ====================================================================================

print('Exporting multizone Rolling Horizon results --> ...')

results_dir = os.path.join('.', 'results', scen)
if os.path.isdir(results_dir):
    shutil.rmtree(results_dir)
os.makedirs(results_dir, exist_ok=True)

# Paleta de colores base
pal2 = [
    '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728',
    '#9467bd', '#8c564b', '#e377c2', '#7f7f7f',
    '#bcbd22', '#17becf', '#aec7e8', '#ffbb78'
]

# Orden fijo de combustibles para plots y leyenda
FUEL_ORDER = [
    'Biomass', 'Coal', 'Gas', 'Hydro', 'Nuclear', 'Oil',
    'Solar', 'Wind', 'shed_load', 'Import', 'Export'
]
FUEL_COLOR_MAP = {fuel: pal2[i % len(pal2)] for i, fuel in enumerate(FUEL_ORDER)}

# Handles fijos para la leyenda (siempre la misma en todos los plots)
LEGEND_HANDLES = [
    Patch(facecolor=FUEL_COLOR_MAP[fuel], label=fuel) for fuel in FUEL_ORDER
]

EMISSION_ORDER = ['CO2_power', 'CO2_heat', 'CO2_industry']
EMISSION_COLOR_MAP = {
    'CO2_power': '#4C78A8',
    'CO2_heat': '#F58518',
    'CO2_industry': '#54A24B',
}


# ====================================================================================
# Funciones helper
# ====================================================================================

def safe_get_demand_series(region, year, demand_dict=None):
    if demand_dict is None:
        return None
    try:
        demand_series = None
        for sector in demand_sectors:
            key = (region, sector, year)
            if key not in demand_dict:
                continue
            df_dem = demand_dict[key]
            if demand_series is None:
                demand_series = df_dem.copy()
            else:
                demand_series = demand_series.add(df_dem, fill_value=0.0)
        if demand_series is None:
            return None
        return demand_series.sort_index()
    except Exception:
        return None


def plot_generation_region(gen_df, region_label='Region', demand_dict=None):
    """
    gen_df: index = (year, period), columns = fuels + shed_load + Net_Trade + Import + Export

    - En TODOS los plots:
        * El stack incluye sólo columnas de FUEL_ORDER que existan en gen_df
          (Biomass, Coal, ..., shed_load, Import, Export).
        * Import es >= 0, Export es <= 0 (por lo que aparecen como barras/áreas
          negativas en los gráficos).
        * NO se dibuja Net_Trade (ni como línea ni nada).
    - La leyenda es SIEMPRE la misma (FUEL_ORDER), aunque alguna serie no exista
      o esté siempre en cero.
    """
    if gen_df is None or gen_df.empty:
        print(f'No generation data to plot for {region_label}')
        return

    gen_df = gen_df.copy()

    # Detectar columna Net_Trade para excluirla del stack
    trade_col = None
    for c in gen_df.columns:
        if c.lower() in ['net_trade', 'trade', 'import_export', 'net_import']:
            trade_col = c
            break

    # Columnas presentes que pertenecen al orden fijo de combustibles
    stack_cols = [f for f in FUEL_ORDER if f in gen_df.columns]

    # ---------------------- 1) Perfiles anuales ----------------------
    years_local = sorted(gen_df.index.get_level_values('year').unique())
    n_years = len(years_local)

    if n_years == 1:
        # ----- Gen_by_fuel_XX_year_YYYY.png -----
        year = years_local[0]
        df_year = gen_df.xs(year, level='year')
        periods_sorted = sorted(df_year.index)
        y_vals = [df_year.loc[periods_sorted, col].values for col in stack_cols]
        colors = [FUEL_COLOR_MAP[col] for col in stack_cols]

        fig, ax = plt.subplots(figsize=(10, 4))
        if stack_cols:
            ax.stackplot(periods_sorted, y_vals,
                         labels=stack_cols,
                         colors=colors)
        ax.set_title(f'Generation by fuel - {region_label}, year {year}')
        ax.set_xlabel('Period')
        ax.set_ylabel('Dispatch / flows [GWh]')

        # Demanda
        if demand_dict is not None:
            dem_series = safe_get_demand_series(region_label, year, demand_dict)
            if dem_series is not None:
                ax.plot(periods_sorted,
                        dem_series.loc[periods_sorted],
                        linewidth=1.5,
                        label='Demand')

        # Leyenda fija con todos los combustibles
        ax.legend(handles=LEGEND_HANDLES, loc='upper right', fontsize=8, ncol=2)
        fig.tight_layout()
        fig.savefig(os.path.join(results_dir,
                                 f'Gen_by_fuel_{region_label}_year_{year}.png'))
        plt.close(fig)

    else:
        # ----- Gen_by_fuel_XX_all_years.png -----
        nrows = n_years
        fig, axes = plt.subplots(nrows, 1,
                                 figsize=(10, 3 * n_years),
                                 sharex=True)
        if nrows == 1:
            axes = [axes]

        for ax, year in zip(axes, years_local):
            df_year = gen_df.xs(year, level='year')
            periods_sorted = sorted(df_year.index)
            y_vals = [df_year.loc[periods_sorted, col].values for col in stack_cols]
            colors = [FUEL_COLOR_MAP[col] for col in stack_cols]

            if stack_cols:
                ax.stackplot(periods_sorted, y_vals,
                             labels=stack_cols,
                             colors=colors)
            ax.set_title(f'{region_label} - year {year}')
            ax.set_ylabel('Dispatch / flows [GWh]')

            # Demanda
            if demand_dict is not None:
                dem_series = safe_get_demand_series(region_label, year, demand_dict)
                if dem_series is not None:
                    ax.plot(periods_sorted,
                            dem_series.loc[periods_sorted],
                            linewidth=1.0,
                            label='Demand')

        axes[-1].set_xlabel('Period')

        # Leyenda fija
        fig.legend(handles=LEGEND_HANDLES,
                   loc='upper center', fontsize=8, ncol=4)
        fig.tight_layout(rect=[0, 0, 1, 0.95])
        fig.savefig(os.path.join(results_dir,
                                 f'Gen_by_fuel_{region_label}_all_years.png'))
        plt.close(fig)

    # ---------------------- 2) Barras anuales ----------------------
    gen_yearly = gen_df.groupby('year').sum()

    # Columnas para el stack anual: intersección FUEL_ORDER
    fuel_cols_yearly = [f for f in FUEL_ORDER if f in gen_yearly.columns]

    fig, ax = plt.subplots(figsize=(8, 4))
    if fuel_cols_yearly:
        gen_yearly[fuel_cols_yearly].plot(
            kind='bar',
            ax=ax,
            stacked=True,
            color=[FUEL_COLOR_MAP[f] for f in fuel_cols_yearly]
        )

    ax.set_title(f'Annual generation by fuel - {region_label}')
    ax.set_xlabel('Year')
    ax.set_ylabel('Generation / flows [GWh]')

    # Sin Net_Trade en el plot anual
    ax.legend(handles=LEGEND_HANDLES, loc='upper right', fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(os.path.join(results_dir,
                             f'Gen_by_fuel_{region_label}_annual.png'))
    plt.close(fig)


def plot_hydro_region(storage_df, region_label='Region'):
    if storage_df is None or storage_df.empty:
        print(f'No hydro storage data to plot for {region_label}')
        return

    years_local = sorted(storage_df.index.get_level_values('year').unique())
    n_years = len(years_local)
    units = storage_df.columns

    if n_years == 1:
        year = years_local[0]
        df_year = storage_df.xs(year, level='year')
        periods_sorted = sorted(df_year.index)
        y_vals = [df_year.loc[periods_sorted, u].values for u in units]

        fig, ax = plt.subplots(figsize=(10, 4))
        ax.stackplot(periods_sorted, y_vals, labels=units,
                     colors=pal2[:len(units)])
        ax.set_title(f'Hydro storage level - {region_label}, year {year}')
        ax.set_xlabel('Period')
        ax.set_ylabel('Storage level [GWh]')
        ax.legend(loc='upper right', fontsize=8, ncol=2)
        fig.tight_layout()
        fig.savefig(os.path.join(results_dir,
                                 f'Hydro_storage_{region_label}_year_{year}.png'))
        plt.close(fig)
    else:
        nrows = n_years
        fig, axes = plt.subplots(nrows, 1,
                                 figsize=(10, 3 * n_years),
                                 sharex=True)
        if nrows == 1:
            axes = [axes]
        for ax, year in zip(axes, years_local):
            df_year = storage_df.xs(year, level='year')
            periods_sorted = sorted(df_year.index)
            y_vals = [df_year.loc[periods_sorted, u].values for u in units]
            ax.stackplot(periods_sorted, y_vals, labels=units,
                         colors=pal2[:len(units)])
            ax.set_title(f'{region_label} - year {year}')
            ax.set_ylabel('Storage level [GWh]')
        axes[-1].set_xlabel('Period')
        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='upper center', fontsize=8, ncol=4)
        fig.tight_layout(rect=[0, 0, 1, 0.95])
        fig.savefig(os.path.join(results_dir,
                                 f'Hydro_storage_{region_label}_all_years.png'))
        plt.close(fig)


def plot_industry_region(fuel_use_df, region_label='Region'):
    if fuel_use_df is None or fuel_use_df.empty:
        print(f'No industry fuel data to plot for {region_label}')
        return
    if (fuel_use_df.sum().abs() == 0).all():
        print(f'Industry fuel use all zero for {region_label}, skipping plot.')
        return

    years_local = sorted(fuel_use_df.index.get_level_values('year').unique())
    n_years = len(years_local)
    fuels_local = fuel_use_df.columns

    if n_years == 1:
        year = years_local[0]
        df_year = fuel_use_df.xs(year, level='year')
        periods_sorted = sorted(df_year.index)
        y_vals = [df_year.loc[periods_sorted, f].values for f in fuels_local]

        fig, ax = plt.subplots(figsize=(10, 4))
        ax.stackplot(periods_sorted, y_vals,
                     labels=fuels_local,
                     colors=pal2[:len(fuels_local)])
        ax.set_title(f'Industry fuel use - {region_label}, year {year}')
        ax.set_xlabel('Period')
        ax.set_ylabel('Fuel use [GWh]')
        ax.legend(loc='upper right', fontsize=8, ncol=2)
        fig.tight_layout()
        fig.savefig(os.path.join(results_dir,
                                 f'Industry_fuel_use_{region_label}_year_{year}.png'))
        plt.close(fig)
    else:
        nrows = n_years
        fig, axes = plt.subplots(nrows, 1,
                                 figsize=(10, 3 * n_years),
                                 sharex=True)
        if nrows == 1:
            axes = [axes]
        for ax, year in zip(axes, years_local):
            df_year = fuel_use_df.xs(year, level='year')
            periods_sorted = sorted(df_year.index)
            y_vals = [df_year.loc[periods_sorted, f].values for f in fuels_local]
            ax.stackplot(periods_sorted, y_vals,
                         labels=fuels_local,
                         colors=pal2[:len(fuels_local)])
            ax.set_title(f'Industry fuel use - {region_label}, year {year}')
            ax.set_ylabel('Fuel use [GWh]')
        axes[-1].set_xlabel('Period')
        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='upper center', fontsize=8, ncol=4)
        fig.tight_layout(rect=[0, 0, 1, 0.95])
        fig.savefig(os.path.join(results_dir,
                                 f'Industry_fuel_use_{region_label}_all_years.png'))
        plt.close(fig)


def plot_emissions_region(co2_df, region_label='Region'):
    if co2_df is None or co2_df.empty:
        print(f'No CO2 data to plot for {region_label}')
        return

    co2_df = co2_df.copy()
    for col in EMISSION_ORDER:
        if col not in co2_df.columns:
            co2_df[col] = 0.0

    co2_df = co2_df[EMISSION_ORDER].sort_index()

    fig, ax = plt.subplots(figsize=(8, 4))
    co2_df.plot(
        kind='bar',
        stacked=True,
        ax=ax,
        color=[EMISSION_COLOR_MAP[c] for c in EMISSION_ORDER]
    )
    ax.set_title(f'Annual CO2 emissions - {region_label}')
    ax.set_xlabel('Year')
    ax.set_ylabel('CO2 emissions')
    ax.legend(loc='upper right', fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(results_dir, f'CO2_emissions_{region_label}_annual.png'))
    plt.close(fig)


# ====================================================================================
# 1. Net trade + matriz Import-export
# ====================================================================================

net_trade = {}       # (region, period, year) -> net import (import - export)
pair_imports_by_year = defaultdict(list)

# imports_from_results[(to, n_from, period, year)] = flow from n_from -> to
for year in years:
    for period in periods:
        for n_from in systems:
            for to in systems:
                if to == n_from:
                    continue
                key = (to, n_from, period, year)
                if key not in imports_from_results:
                    continue

                flow = imports_from_results[key]

                # Guardamos la fila en la lista del año correspondiente
                pair_imports_by_year[year].append(
                    [year, period, to, n_from, round(flow, 2)]
                )

                # net import(+)/export(-)
                net_trade[(to, period, year)] = \
                    net_trade.get((to, period, year), 0.0) + flow
                net_trade[(n_from, period, year)] = \
                    net_trade.get((n_from, period, year), 0.0) - flow

# Escribir un Excel con una hoja por año
if save_csv and pair_imports_by_year:
    import_path = os.path.join(results_dir, 'Import-export.xlsx')
    with pd.ExcelWriter(import_path) as writer:
        for year, rows in pair_imports_by_year.items():
            df_imports_pairs = pd.DataFrame(
                rows,
                columns=['Year', 'Period', 'Region To', 'Region From', 'Trade']
            )
            # Nombre de la hoja, p.ej. "Y2020"
            sheet_name = f'Y{year}'
            df_imports_pairs.to_excel(
                writer,
                sheet_name=sheet_name,
                index=False
            )
    print(f'Import-export guardado por año en: {import_path}')

# ====================================================================================
# 2. DataFrames por región
# ====================================================================================

gen_region_dict = {}
hydro_region_dict = {}
ind_region_dict = {}
co2_region_dict = {}

co2_power_dict = globals().get('CO2_total_results', {})
co2_heat_dict = globals().get('CO2_total_heat_results', {})
co2_industry_dict = globals().get('CO2_total_industry_results', {})
if ('CO2_total_results' not in globals() or
        'CO2_total_heat_results' not in globals() or
        'CO2_total_industry_results' not in globals()):
    print('WARNING: one or more CO2 dictionaries are missing; plotting zero where missing.')

# columna de combustible
if 'fuel' in df.columns:
    fuel_col_name = 'fuel'
elif 'fuel_type' in df.columns:
    fuel_col_name = 'fuel_type'
else:
    fuel_col_name = None
    print("WARNING: df has no 'fuel' or 'fuel_type'; using 'Other' as Fuel.")

for region in systems:
    print(f'  -> Procesando región: {region}')

    # -------- GENERACIÓN + Net_Trade + shed_load ----------
    generation_list = []
    extra_list = []

    for year in years:
        for genco in unit_system[region]:
            if fuel_col_name is not None:
                fuel_row = df[(df['unit_name'] == genco) &
                              (df['system'] == region)]
                if not fuel_row.empty:
                    fuel = fuel_row[fuel_col_name].iloc[0]
                else:
                    fuel = 'Other'
            else:
                fuel = 'Other'

            for period in periods:
                key = (region, genco, period, year)
                if key not in generation_results:
                    continue
                generation_list.append([
                    region, genco, period, year, fuel,
                    round(generation_results[key], 2)
                ])

        for period in periods:
            net = net_trade.get((region, period, year), 0.0)
            extra_list.append([
                region, 'Net_Trade', period, year, 'Net_Trade',
                round(net, 2)
            ])
            extra_list.append([
                region, 'shed_load', period, year, 'shed_load',
                round(noload_elec_results[region, period, year], 2)
            ])

    df_gen = pd.DataFrame(
        generation_list,
        columns=['Region', 'Unit', 'period', 'year', 'Fuel', 'Dispatch']
    )
    df_extra = pd.DataFrame(
        extra_list,
        columns=['Region', 'Unit', 'period', 'year', 'Fuel', 'Dispatch']
    )
    df_combined = pd.concat([df_gen, df_extra], ignore_index=True)

    df_tmp = df_combined[['Region', 'year', 'period', 'Fuel', 'Dispatch']]
    df_group = df_tmp.groupby(['Region', 'year', 'period', 'Fuel']).sum().reset_index()

    gen_by_fuel_region = df_group.pivot_table(
        index=['year', 'period'],
        columns='Fuel',
        values='Dispatch'
    ).fillna(0.0)

    # Añadir Import (>=0) y Export (<=0) a partir de Net_Trade
    if 'Net_Trade' in gen_by_fuel_region.columns:
        net_series = gen_by_fuel_region['Net_Trade']
        gen_by_fuel_region['Import'] = net_series.clip(lower=0)
        gen_by_fuel_region['Export'] = net_series.clip(upper=0)

    gen_region_dict[region] = gen_by_fuel_region

    if save_csv:
        gen_by_fuel_region.to_excel(
            os.path.join(results_dir, f'gen_by_fuel_wide_GWh_{region}.xlsx'),
            sheet_name=f'generation_wide_{region}',
            index=True
        )

    plot_generation_region(gen_by_fuel_region, region_label=region, demand_dict=None)

    # -------- HYDRO ----------
    storage_total = []
    for year in years:
        for hdam in hydro_storage_units:
            if hdam not in unit_system[region]:
                continue
            for period in periods:
                key = (region, hdam, period, year)
                if key not in storage_level_results:
                    continue
                storage_total.append([
                    region, hdam, period, year,
                    round(storage_level_results[key], 2)
                ])
    if storage_total:
        storage_total_df_region = pd.DataFrame(
            storage_total,
            columns=['Region', 'Unit', 'period', 'year', 'StorageLevel']
        )
        storage_region = storage_total_df_region[
            ['Region', 'year', 'period', 'Unit', 'StorageLevel']
        ]
        storage_group = storage_region.groupby(
            ['Region', 'year', 'period', 'Unit']
        ).sum().reset_index()
        storage_by_unit_region = storage_group.pivot_table(
            index=['year', 'period'],
            columns='Unit',
            values='StorageLevel'
        ).fillna(0.0)
    else:
        storage_by_unit_region = pd.DataFrame()

    hydro_region_dict[region] = storage_by_unit_region

    if save_csv and not storage_by_unit_region.empty:
        storage_by_unit_region.to_excel(
            os.path.join(results_dir, f'StorageLevel_Hydro_{region}.xlsx'),
            sheet_name=f'HydroStorageLevel_{region}',
            index=True
        )
    plot_hydro_region(storage_by_unit_region, region_label=region)

    # -------- INDUSTRIA ----------
    fuel_use_ind_list = []
    H2_use_ind_list = []

    for year in years:
        for fuel in industry_fuels:
            for period in periods:
                key = (region, fuel, period, year)
                if key not in Fuel_ind_results:
                    continue
                fuel_use_ind_list.append([
                    region, fuel, period, year,
                    round(Fuel_ind_results[key], 2)
                ])
        for period in periods:
            key_h2 = (region, period, year)
            if key_h2 not in H2tInd_results:
                continue
            H2_use_ind_list.append([
                region, 'H2_ind', period, year,
                round(H2tInd_results[key_h2], 2)
            ])

    if fuel_use_ind_list or H2_use_ind_list:
        df_fuel_ind = pd.DataFrame(
            fuel_use_ind_list,
            columns=['Region', 'Fuel', 'period', 'year', 'Use']
        ) if fuel_use_ind_list else pd.DataFrame(
            columns=['Region', 'Fuel', 'period', 'year', 'Use']
        )
        df_H2_ind = pd.DataFrame(
            H2_use_ind_list,
            columns=['Region', 'Fuel', 'period', 'year', 'Use']
        ) if H2_use_ind_list else pd.DataFrame(
            columns=['Region', 'Fuel', 'period', 'year', 'Use']
        )
        df_ind_combined = pd.concat([df_fuel_ind, df_H2_ind], ignore_index=True)
        df_ind_tmp = df_ind_combined[['Region', 'year', 'period', 'Fuel', 'Use']]
        df_ind_group = df_ind_tmp.groupby(
            ['Region', 'year', 'period', 'Fuel']
        ).sum().reset_index()
        ind_by_fuel_region = df_ind_group.pivot_table(
            index=['year', 'period'],
            columns='Fuel',
            values='Use'
        ).fillna(0.0)
    else:
        ind_by_fuel_region = pd.DataFrame()

    ind_region_dict[region] = ind_by_fuel_region

    if save_csv and not ind_by_fuel_region.empty:
        ind_by_fuel_region.to_excel(
            os.path.join(results_dir, f'Industry_fuel_use_{region}.xlsx'),
            sheet_name=f'Industry_fuel_use_{region}',
            index=True
        )
    plot_industry_region(ind_by_fuel_region, region_label=region)

    # -------- EMISIONES CO2 ----------
    co2_rows = []
    for year in years:
        co2_rows.append([
            year,
            round(co2_power_dict.get((region, year), 0.0), 2),
            round(co2_heat_dict.get((region, year), 0.0), 2),
            round(co2_industry_dict.get((region, year), 0.0), 2),
        ])

    co2_by_year_region = pd.DataFrame(
        co2_rows,
        columns=['year', 'CO2_power', 'CO2_heat', 'CO2_industry']
    ).set_index('year').sort_index()

    co2_region_dict[region] = co2_by_year_region

    if save_csv:
        co2_by_year_region.to_excel(
            os.path.join(results_dir, f'CO2_emissions_{region}.xlsx'),
            sheet_name=f'CO2_emissions_{region}',
            index=True
        )
    plot_emissions_region(co2_by_year_region, region_label=region)

# ====================================================================================
# 3. Agregados ALL
# ====================================================================================

# GENERACIÓN ALL
gen_all = None
for region, df_region in gen_region_dict.items():
    if df_region is None or df_region.empty:
        continue
    if gen_all is None:
        gen_all = df_region.copy()
    else:
        gen_all = gen_all.add(df_region, fill_value=0.0)

if gen_all is not None and not gen_all.empty:
    # En ALL la Net_Trade total debería ser ~0; dejamos Import/Export en 0
    if 'Net_Trade' in gen_all.columns:
        gen_all['Net_Trade'] = 0.0
    if 'Import' in gen_all.columns:
        gen_all['Import'] = 0.0
    if 'Export' in gen_all.columns:
        gen_all['Export'] = 0.0

    if save_csv:
        gen_all.to_excel(
            os.path.join(results_dir, 'gen_by_fuel_wide_GWh_ALL.xlsx'),
            sheet_name='generation_wide_ALL',
            index=True
        )

    plot_generation_region(gen_all, region_label='ALL', demand_dict=None)

# HYDRO ALL
hydro_all = None
for region, df_region in hydro_region_dict.items():
    if df_region is None or df_region.empty:
        continue
    if hydro_all is None:
        hydro_all = df_region.copy()
    else:
        hydro_all = hydro_all.add(df_region, fill_value=0.0)

if hydro_all is not None and not hydro_all.empty:
    if save_csv:
        hydro_all.to_excel(
            os.path.join(results_dir, 'StorageLevel_Hydro_ALL.xlsx'),
            sheet_name='HydroStorageLevel_ALL',
            index=True
        )
    plot_hydro_region(hydro_all, region_label='ALL')

# INDUSTRIA ALL
ind_all = None
for region, df_region in ind_region_dict.items():
    if df_region is None or df_region.empty:
        continue
    if ind_all is None:
        ind_all = df_region.copy()
    else:
        ind_all = ind_all.add(df_region, fill_value=0.0)

if ind_all is not None and not ind_all.empty:
    if save_csv:
        ind_all.to_excel(
            os.path.join(results_dir, 'Industry_fuel_use_ALL.xlsx'),
            sheet_name='Industry_fuel_use_ALL',
            index=True
        )
    plot_industry_region(ind_all, region_label='ALL')

# EMISIONES CO2 ALL
co2_all = None
for region, df_region in co2_region_dict.items():
    if df_region is None or df_region.empty:
        continue
    if co2_all is None:
        co2_all = df_region.copy()
    else:
        co2_all = co2_all.add(df_region, fill_value=0.0)

if co2_all is not None and not co2_all.empty:
    if save_csv:
        co2_all.to_excel(
            os.path.join(results_dir, 'CO2_emissions_ALL.xlsx'),
            sheet_name='CO2_emissions_ALL',
            index=True
        )
    plot_emissions_region(co2_all, region_label='ALL')

print('Done exporting and plotting multizone Rolling Horizon results.')
