# -*- coding: utf-8 -*-
"""
Created on Mon Sep 22 15:58:10 2025


"""

if (Rolling_Horizon == False):
    print('Building and solve the model')
    exec(open("scripts/Build_model.py").read())
    print('Printing and ploting results')
    exec(open("scripts/export_plot.py").read())
    exec(open("scripts/combine_plot.py").read())


if (Rolling_Horizon == True):

###############################################################################
#####################ROLLING HORIZON MODEL#####################################
###############################################################################

    hor_yrs = years
    years = []  # This list will be updated in each iteration
    
    
    ############### INITIALIZE THE CUMULATIVE INVESTMENT VARIABLES ################
    cap_inv_cumulative                  = {(r,u, y): 0.0        for r in systems for u in units for y in hor_yrs}
    cap_inv_FC_cumulative               = {(r,u, y): 0.0        for r in systems for u in FC_units for y in hor_yrs}
    heat_pump_dh_cap_cumulative         = {(r, v, u, y): 0.0    for r in systems for u in HeatPump_units if u in flexUnit_system[r] for v in chp_units if v in CHPMarket_system_check[r] for y in hor_yrs}
    heat_pump_ind_cap_cumulative        = {(r,u, y): 0.0        for r in systems for u in HeatPump_units if u in flexUnit_system[r] for y in hor_yrs}
    trad_boiler_ind_cap_inv_cumulative  = {(r,u, y): 0.0        for r in systems for u in thermal_units for y in hor_yrs}
    trad_boiler_dh_cap_inv_cumulative   = {(r, v, u, y): 0.0    for r in systems for u in thermal_units for v in chp_units for y in hor_yrs}
    stat_sto_cap_inv_cumulative         = {(r, u, y): 0.0       for r in systems for u in Stat_storage_unit for y in hor_yrs}
    h2_sto_max_cap_cumulative           = {(r, u, y): 0.0       for r in systems for u in H2_storage_unit for y in hor_yrs}
    h2_electrolysis_max_cap_cumulative  = {(r, u, y): 0.0       for r in systems for u in Elec_h2_units for y in hor_yrs}
    transfer_inv_cumulative             = {(t, f, y): 0.0       for t in set(N_To) for f in set(N_From) if f in link_check[t] for y in hor_yrs}
    
    #####INITIALIZE DICTIONARIES TO STORE THE INVESTMENT VALUES FROM SUBPROBLEM####
    values_cap_inv                  = {}
    values_cap_inv_FC               = {}
    values_heat_pump_dh_cap         = {}
    values_heat_pump_ind_cap        = {}
    values_trad_boiler_ind_cap_inv  = {}
    values_trad_boiler_dh_cap_inv   = {}
    values_stat_sto_cap_inv         = {}
    values_h2_sto_max_cap           = {}
    values_h2_electrolysis_max_cap  = {}
    values_transfer_inv             = {}
    
    #####INITIALIZE DICTIONARIES TO STORE THE VARIABLE VALUES FROM SUBPROBLEM####
    generation_results              = {}
    imports_results                 = {}
    imports_from_results            = {} # New variable to store the imports from each node to each node
    ceep_results                    = {}
    cap_inv_results                 = {}
    noload_elec_results             = {}
    noload_heat_ind_results         = {}
    noload_heat_dh_results          = {}
    CO2_total_results               = {}
    CO2_total_heat_results          = {}
    CO2_total_industry_results      = {}
    cap_inv_FC_results              = {}
    generation_FC_results           = {}
    storage_level_results           = {}
    sto_out_flow_results            = {}
    heat_gen_results                = {}
    Fuel_ind_results                = {}
    H2tInd_results                  = {}
    heat_pump_dh_results            = {}
    heat_pump_ind_results           = {}
    heat_pump_dh_cap_results        = {}
    heat_pump_ind_cap_results       = {}
    boiler_dh_generation_results    = {}
    boiler_ind_generation_results   = {}
    trad_boiler_ind_cap_inv_results = {}
    trad_boiler_dh_cap_inv_results  = {}
    ResToHeat_results               = {}
    ev_sto_in_results               = {}
    ev_sto_out_results              = {}
    ev_sto_soc_results              = {}
    stat_sto_in_results             = {}
    stat_sto_out_results            = {}
    stat_sto_cap_inv_results        = {}
    power_to_h2_results             = {}
    h2_sto_soc_results              = {}
    h2_sto_out_results              = {}
    h2_sto_max_cap_results          = {}
    h2_electrolysis_max_cap_results = {}
    generation_H2_results           = {}
    transfer_inv_results            = {} 
    
    ########RUN THE LOOP OF SOLVING SUBPROBLEM AND UPDATION OF INVESTMENTS#########
    for i in range(len(hor_yrs)):
        years = hor_yrs[i : i + window]  # Update the list with a single year
        #scen = 'Subproblem_' + str(i) + '_' + str(hor_yrs[i])
        #scen  = 'Myopic_model'
        print(f"Building and solving the submodel for the year {hor_yrs[i]} in multizone case")
        exec(open("scripts/Build_model.py").read())
        print(f"Run for Submodel in multizone case for the year {hor_yrs[i]} completed")
        
        
        ##############STORE VARIABLE VALUES FROM THE SUBPROBLEM####################
        for region in systems:
            for year in years:
                for unit in unit_system[region]:
                    values_cap_inv[(region, unit, year)] = cap_inv[region, unit, year].X
        
                for unit in FC_units: 
                    if unit in flexUnit_system[region]:
                        values_cap_inv_FC[(region, unit, year)] = cap_inv_FC[region, unit, year].X
  
                for unit in HeatPump_units:
                    if unit in flexUnit_system[region]:
                        values_heat_pump_ind_cap[(region, unit, year)] = heat_pump_ind_cap[region, unit, year].X
                        for chp in chp_units:
                            if chp in CHPMarket_system_check[region]:
                                values_heat_pump_dh_cap[(region, chp, unit, year)] = heat_pump_dh_cap[region, chp, unit, year].X
        
                for unit in thermal_units:
                    values_trad_boiler_ind_cap_inv[(region, unit, year)] = trad_boiler_ind_cap_inv[region, unit, year].X
                    for chp in chp_units:
                        if chp in CHPMarket_system_check[region]:
                            values_trad_boiler_dh_cap_inv[(region, chp, unit, year)] = trad_boiler_dh_cap_inv[region, chp, unit, year].X
  
                for unit in Stat_storage_unit:
                    if unit in flexUnit_system[region]:
                        values_stat_sto_cap_inv[(region, unit, year)] = stat_sto_cap_inv[region, unit, year].X
        
                for unit in H2_storage_unit:
                    if unit in flexUnit_system[region]:
                        values_h2_sto_max_cap[(region, unit, year)] = h2_sto_max_cap[region, unit, year].X
        
                for unit in Elec_h2_units:
                    if unit in flexUnit_system[region]:
                        values_h2_electrolysis_max_cap[(region, unit, year)] = h2_electrolysis_max_cap[region, unit, year].X    
        
                for to in set(N_To):
                    for n_from in set(N_From):
                        if n_from in link_check[to]:
                            values_transfer_inv[(to, n_from, year)] = transfer_inv[to, n_from, year].X
                            
        ##########UPDATE THE CUMULATIVE INVESTMENTS FOR THE NEXT SUBPROBLEM########
        for j in range(i + 1, min(i + 1 + window, len(hor_yrs))):
            for r in systems:
                for u in unit_system[r]:    
                    cap_inv_cumulative[(r, u, hor_yrs[j])] = gp.quicksum(values_cap_inv[(r, u, hor_yrs[ip])] * round(((1-decom_rate[u])**(max(decom_start_new[u]-1, hor_yrs[j] - hor_yrs[ip]) - (decom_start_new[u]-1))), 3) for ip in range(len(hor_yrs)) if ip < j)
                    
                for u in FC_units:
                    if u in flexUnit_system[r]:
                        cap_inv_FC_cumulative[(r, u, hor_yrs[i+1])] = cap_inv_FC_cumulative[(r, u, hor_yrs[i])] + values_cap_inv_FC[(r, u, hor_yrs[i])]
        
                for u in HeatPump_units:
                    if u in flexUnit_system[r]:
                        heat_pump_ind_cap_cumulative[(r, u, hor_yrs[i+1])] = gp.quicksum(values_heat_pump_ind_cap[(r, u, hor_yrs[ip])] *round(((1-HP_decom_rate[r,u])**(max(HP_decom_start_new[r, u]-1, hor_yrs[i+1]-hor_yrs[ip])-(HP_decom_start_new[r, u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
                        for v in chp_units:
                            if v in CHPMarket_system_check[r]:
                                heat_pump_dh_cap_cumulative[(r, v, u, hor_yrs[i+1])] = gp.quicksum(values_heat_pump_dh_cap[(r, v, u, hor_yrs[ip])] *round(((1-HP_decom_rate[r, u])**(max(HP_decom_start_new[r,u]-1, hor_yrs[i+1]-hor_yrs[ip])-(HP_decom_start_new[r, u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
            
                for u in thermal_units:
                    trad_boiler_ind_cap_inv_cumulative[(r, u, hor_yrs[i+1])] = gp.quicksum(values_trad_boiler_ind_cap_inv[(r, u, hor_yrs[ip])] *round(((1-Boiler_decom_rate[r, u])**(max(Boiler_decom_start_new[r, u]-1,hor_yrs[i+1]-hor_yrs[ip])-(Boiler_decom_start_new[r, u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
                    for v in chp_units:
                        if v in CHPMarket_system_check[r]:
                            trad_boiler_dh_cap_inv_cumulative[(r, v, u, hor_yrs[i+1])] = gp.quicksum(values_trad_boiler_dh_cap_inv[(r, v, u, hor_yrs[ip])] *round(((1-Boiler_decom_rate[r, u])**(max(Boiler_decom_start_new[r, u]-1,hor_yrs[i+1]-hor_yrs[ip])-(Boiler_decom_start_new[r, u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
                
                for u in Stat_storage_unit:
                    if u in flexUnit_system[r]:
                        stat_sto_cap_inv_cumulative[(r, u, hor_yrs[i+1])] = gp.quicksum(values_stat_sto_cap_inv[(r, u, hor_yrs[ip])] *round(((1-Sta_sto_decom_rate[r, u])**(max(Sta_sto_decom_start_new[r, u]-1 ,hor_yrs[i+1]-hor_yrs[ip])-(Sta_sto_decom_start_new[r, u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
                    
                for u in H2_storage_unit:
                    if u in flexUnit_system[r]:
                        h2_sto_max_cap_cumulative[(r, u, hor_yrs[i+1])] = h2_sto_max_cap_cumulative[(r, u, hor_yrs[i])] + values_h2_sto_max_cap[(r, u, hor_yrs[i])]
                
                for u in Elec_h2_units:
                    if u in flexUnit_system[r]:
                        h2_electrolysis_max_cap_cumulative[(r, u, hor_yrs[i+1])] = h2_electrolysis_max_cap_cumulative[(r, u, hor_yrs[i])] + values_h2_electrolysis_max_cap[(r, u, hor_yrs[i])]
            for t in set(N_To):
                for f in set(N_From):
                    if f in link_check[t]:
                        transfer_inv_cumulative[(t, f, hor_yrs[i+1])] = transfer_inv_cumulative[(t, f, hor_yrs[i])] + values_transfer_inv[(t, f, hor_yrs[i])]
        
        ##############STORE VARIABLE VALUES FROM THE SUBPROBLEM####################
        for region in systems:
            for genco in unit_system[region]:
                cap_inv_results[region, genco, years[0]] = cap_inv[region, genco, years[0]].x
                for period in periods:
                    generation_results[region, genco, period, years[0]] = generation[region, genco, period, years[0]].x
    
            for period in periods:
                imports_results[region, period, years[0]] = imports[region, period, years[0]].x
                ceep_results[region, period, years[0]] = ceep[region, period, years[0]].x
                noload_elec_results[region, period, years[0]] = noload_elec[region, period, years[0]].x
                noload_heat_ind_results[region, period, years[0]] = noload_heat_ind[region, period, years[0]].x
                ResToHeat_results[region, period, years[0]] = ResToHeat[region, period, years[0]].x
                ev_sto_in_results[region, period, years[0]] = ev_sto_in[region, period, years[0]].x
                ev_sto_out_results[region, period, years[0]] = ev_sto_out[region, period, years[0]].x
                ev_sto_soc_results[region, period, years[0]] = ev_sto_soc[region, period, years[0]].x
                power_to_h2_results[region, period, years[0]] = power_to_h2[region, period, years[0]].x
                H2tInd_results[region, period, years[0]] = H2tInd[region, period, years[0]].x
    
            for unit in chp_units:
                if unit in CHPMarket_system_check[region]:
                    for period in periods:
                        noload_heat_dh_results[region, unit, period, years[0]] = noload_heat_dh[region, unit, period, years[0]].x
                        heat_gen_results[region, unit, period, years[0]] = heat_gen[region, unit, period, years[0]].x
    
            for unit in FC_units:
                if unit in flexUnit_system[region]:
                    cap_inv_FC_results[region, unit, years[0]] = cap_inv_FC[region, unit, years[0]].x
                    for period in periods:
                        generation_FC_results[region, unit, period, years[0]] = generation_FC[region, unit, period, years[0]].x
    
            for unit in unit_system[region]:
                if unit in hydro_storage_units:
                    for period in periods:
                        storage_level_results[region, unit, period, years[0]] = storage_level[region, unit, period, years[0]].x
                        sto_out_flow_results[region, unit, period, years[0]] = sto_out_flow[region, unit, period, years[0]].x
    
            for fuel in industry_fuels:
                for period in periods:
                    Fuel_ind_results[region, fuel, period, years[0]] = Fuel_ind[region, fuel, period, years[0]].x
    
            for hp_unit in HeatPump_units:
                heat_pump_ind_cap_results[region, hp_unit, years[0]] = heat_pump_ind_cap[region, hp_unit, years[0]].x
                for period in periods:
                    heat_pump_ind_results[region, hp_unit, period, years[0]] = heat_pump_ind[region, hp_unit, period, years[0]].x
                for chp in chp_units:
                    if chp in CHPMarket_system_check[region]:
                        heat_pump_dh_cap_results[region, chp, hp_unit, years[0]] = heat_pump_dh_cap[region,  chp, hp_unit, years[0]].x
                        for period in periods:
                            heat_pump_dh_results[region, chp, hp_unit, period, years[0]] = heat_pump_dh[region, chp, hp_unit, period, years[0]].x
        
            for unit in thermal_units:
                trad_boiler_ind_cap_inv_results[region, unit, years[0]] = trad_boiler_ind_cap_inv[region, unit, years[0]].x
                for period in periods:
                    boiler_ind_generation_results[region, unit, period, years[0]] = boiler_ind_generation[region, unit, period, years[0]].x
                for chp in chp_units:
                    if chp in CHPMarket_system_check[region]:
                        trad_boiler_dh_cap_inv_results[region, chp, unit, years[0]] = trad_boiler_dh_cap_inv[region, chp, unit, years[0]].x
                        for period in periods:
                            boiler_dh_generation_results[region, chp, unit, period, years[0]] = boiler_dh_generation[region, chp, unit, period, years[0]].x
    
            for unit in Stat_storage_unit:
                if unit in flexUnit_system[region]:
                    stat_sto_cap_inv_results[region, unit, years[0]] = stat_sto_cap_inv[region, unit, years[0]].x
                    for period in periods:
                        stat_sto_in_results[region, unit, period, years[0]] = stat_sto_in[region, unit, period, years[0]].x
                        stat_sto_out_results[region, unit, period, years[0]] = stat_sto_out[region, unit, period, years[0]].x
    
            for unit in H2_storage_unit:
                if unit in flexUnit_system[region]:
                    h2_sto_max_cap_results[region, unit, years[0]] = h2_sto_max_cap[region, unit, years[0]].x
                    for period in periods:
                        h2_sto_soc_results[region, unit, period, years[0]] = h2_sto_soc[region, unit, period, years[0]].x
                        h2_sto_out_results[region, unit, period, years[0]] = h2_sto_out[region, unit, period, years[0]].x
        
            for unit in Elec_h2_units:
                if unit in flexUnit_system[region]:
                    h2_electrolysis_max_cap_results[region, unit, years[0]] = h2_electrolysis_max_cap[region, unit, years[0]].x
                    for period in periods:
                        generation_H2_results[region, unit, period, years[0]] = generation_H2[region, unit, period, years[0]].x
                        
            for to in set(N_To):
                for n_from in set(N_From):
                    if n_from in link_check[to]:
                        transfer_inv_results[(to, n_from, years[0])] = transfer_inv[to, n_from, years[0]].X
                        for period in periods:
                            imports_from_results[(to, n_from, period, years[0])] = imports_from[to, n_from, period, years[0]].X
                            
    
            CO2_total_results[region, years[0]]             = CO2_total[region, years[0]].x
            CO2_total_heat_results[region, years[0]]        = CO2_total_heat[region, years[0]].x
            CO2_total_industry_results[region, years[0]]    = CO2_total_industry[region, years[0]].x    
    
    years = hor_yrs        
    exec(open("scripts/export_plot_multizone_RH.py").read())
    exec(open("scripts/save_all_results_to_csv.py").read())