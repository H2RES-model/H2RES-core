# -*- coding: utf-8 -*-
"""
Created on Thu Jan  7 08:37:00 2021

@author: felipe feijoo
"""
#%%
#MAIN
###############################################################################
######################SENARIO NAME and single parameters#######################
###############################################################################
scen = 'Main_Test'
rps_inv                 = False     # Options: True / False
carbonLimit             = False     # Options: True / False
save_csv                = False     # Options: True / False
res_inv                 = True     # Options: True / False
hydro_storage           = True     # Options: True / False
ceep_limit              = True     # Options: True / False
NoResToHeatInv          = False    # Options: True / False
Rolling_Horizon         = True     # Options: True / False

#National Level limits
Transmission_Inv        = False     # Options: True / False #New parameter
rps_inv_National        = True     # Options: True / False #New parameter
carbonLimit_National    = True     # Options: True / False  New parameter




# 
#ceep_penalty                        = True     # Options: True / False
#fossil_dispatch                     = True     # Options: True / False



#### Time horizon Paramenters #### (Abhishake)
periods                 = list(range(1,24*365))
years                   = list([2025,2030,2035,2040,2045,2050])
#years                   = list([2020])
window                  = 1 #enter a number between 1 and len(years)



#Policy Paramenters
rps_National            = list([ 0.1, 0.63, 0.63, 0.63, 0.63, 1]) # New parameter
CO2_Limit_National      = list([168000000*1,168000000*0.56,168000000*0.56,168000000*0.56,168000000*0.56,168000000*0]) # New parameter


ceep_parameter          = 0.15   # Note that H2RES takes 0.1 = 10% not as 0.1%.
LostLoad_Cost           = 10000000      # Cost for Unserved demand (heat (dh, ind) and electricity) Felipe
Transmission_Cost       = 25000    # New parameter



#General Paramenters
Import_Price     = 45       # $/MWh
Imp_price_inc    = 0.05     # 5% increase in import price pear year. 


#### V2G
V2G_cost        = 25       # Vehicle to grid price $/MWh 
ev_Demand_year  = list([1, 1, 1, 1, 1, 1])  # Total yearly demand per year (MWh)
ev_sto_min      = 0
ev_Grid_eff     = 0.9
number_of_veh   = 1670000   #Number of total vehicles
average_ch_rate = 7         #kW
average_bat     = 50        #kWh
charging_veh    = number_of_veh*average_ch_rate/1000    #MW
stor_veh        = number_of_veh*average_bat/1000        #MWh
ev_Grid_P       = list([0.075*charging_veh, 0.2*charging_veh, 0.4*charging_veh, 0.4*charging_veh, 0.4*charging_veh, 0.4*charging_veh, 0.4*charging_veh])
ev_stor         = list([0.122*stor_veh, 0.143*stor_veh, 0.163*stor_veh,0.184*stor_veh,0.204*stor_veh,0.225*stor_veh,0.25*stor_veh])

###############################################################################
### GENCO/Demand data (enter genco data file name with extension)##############
###############################################################################

system_dat            = './data/MZ/system_data.xlsx'
genco_dat             = './data/MZ/genco_data.csv'
demand_dat            = './data/MZ/demand_2020_2050.csv'
fuel_price_dat        = './data/MZ/fuel_cost_2020_2050.csv'
avl_factor_plant_dat  = './data/MZ/ncre_aval_factor_2020_2050.csv'
inflows_dat           = './data/MZ/scaled_inflows_2020_2050.csv' 
import_export         = './data/MZ/import_export_2020_2050.csv' 
heat_demand_dat       = './data/MZ/heat_demand_2020_2050.csv'
cooling_demand_dat    = './data/MZ/cooling_demand_2020_2050.csv'
ev_transpload_dat     = './data/MZ/ev_transp_load.csv'
h2_demand_dat         = './data/MZ/demand_H2_2020_2050.csv'
flex_tech_dat         = './data/MZ/flex_tech_2020_2050.xlsx'


###############################################################################
### GENCO/Demand data (enter genco data file name with extension)##############
###############################################################################
print('Reading and processing data')
exec(open("scripts/read_process_data.py").read())
print('Building and solve the model')
exec(open("scripts/modeling_approaches.py").read())
###############################################################################
###############################################################################






