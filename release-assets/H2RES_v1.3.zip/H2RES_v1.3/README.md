﻿# H2RES v1.3

## Overview
H2RES v1.3 extends the model from a single-system rolling-horizon framework to a multizone regional structure with bilateral electricity exchanges, optional transmission expansion, and explicit coexistence of regional and national policy layers.

## What improved relative to v1.2
Compared with v1.2, this version makes the largest structural expansion of H2RES:
- the model becomes multizone,
- variables and constraints are regionalized,
- inter-system electricity exchanges are modeled explicitly,
- transmission-capacity investment becomes available,
- national policy layers are added on top of regional system structure.

## Core capabilities
- Regionalized generation, storage, heat, hydrogen, and industrial-fuel representation
- Multizone electricity balances
- Bilateral inter-system power flows
- Optional endogenous transmission expansion
- Rolling-horizon execution retained
- Regional renewable-share constraints
- Regional CO2-cap logic
- National renewable-share constraints
- National CO2-cap logic
- Regional EV flexibility, hydrogen production, hydrogen storage, and sector coupling
- Multizone output reporting and system-level aggregation

## New decision variables introduced in this version
- `imports_from_{to,from,t,y}`: bilateral electricity-import flow from one modeled system to another
- `transfer_inv_{to,from,y}`: endogenous transmission-capacity expansion variable for inter-system transfer corridors
- Regionalized versions of previously single-system variables, now carrying a leading system index, for example `generation_{region,u,t,y}`, `cap_inv_{region,u,y}`, and other sector-coupled operational variables

## Main formulation changes relative to v1.2
- Most implemented operational and investment variables are reformulated with an explicit leading regional or system index.
- Electricity-balance logic is extended from a single aggregated system to multizone regional balances connected by bilateral transfers.
- A transmission-expansion block is introduced through `transfer_inv_{to,from,y}` and associated transfer-capacity constraints.
- National policy layers are added on top of regional model structure through national RPS and national CO2-cap logic.
- The rolling-horizon workflow is retained, but execution is reorganized around a multizone builder and multizone export structure.

## What remains unchanged from v1.2
- Rolling-horizon planning remains available and central to the bundled workflow
- Core sector-coupling architecture across electricity, heat, cooling, hydrogen, and storage is preserved
- Capacity-expansion and dispatch logic remain integrated in one optimization model
- The model still relies on structured preprocessing before the optimization build stage

## Main workflow
The active execution path is based on:
- `main.py`
- `scripts/read_process_data.py`
- `scripts/modeling_approaches.py`
- `scripts/Build_model.py`
- multizone export utilities

## Recommended use
Use v1.3 if you want to perform multiregional planning studies, analyze regional interactions and electricity transfers, study transmission expansion, or combine regional and national policy constraints in the same optimization framework.

## Related documentation
For a full description of model structure, equations, data flow, and interpretation logic, see the corresponding User Manual and Mathematical Formulation documents for this version.

## Caution on cross-version comparison
This version differs from earlier releases not only in data structure, but also in model scope and policy architecture. Direct comparison with single-system versions requires careful harmonization of assumptions and workflow.
