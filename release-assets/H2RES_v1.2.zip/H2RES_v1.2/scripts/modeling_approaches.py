# -*- coding: utf-8 -*-
"""
Created on Mon Sep 22 15:58:10 2025


"""

if (Rolling_Horizon == False):
    print('Building and solve the model')
    exec(open("scripts/Build_model.py").read())
    print('Printing and ploting results')
    exec(open("scripts/export_plot.py").read())
    exec(open("scripts/combine_plot.py").read())


if (Rolling_Horizon == True):

###############################################################################
#####################ROLLING HORIZON MODEL#####################################
###############################################################################

    hor_yrs = years
    years = []  # This list will be updated in each iteration
    
    
    ############### INITIALIZE THE CUMULATIVE INVESTMENT VARIABLES ################
    cap_inv_cumulative = {(u, y): 0.0 for u in units for y in hor_yrs}
    cap_inv_FC_cumulative = {(u, y): 0.0 for u in FC_units for y in hor_yrs}
    heat_pump_dh_cap_cumulative = {(u, v, y): 0.0 for u in HeatPump_units for v in chp_units for y in hor_yrs}
    heat_pump_ind_cap_cumulative = {(u, y): 0.0 for u in HeatPump_units for y in hor_yrs}
    trad_boiler_ind_cap_inv_cumulative = {(u, y): 0.0 for u in thermal_units for y in hor_yrs}
    trad_boiler_dh_cap_inv_cumulative = {(u, v, y): 0.0 for u in thermal_units for v in chp_units for y in hor_yrs}
    stat_sto_cap_inv_cumulative = {(u, y): 0.0 for u in Stat_storage_unit for y in hor_yrs}
    h2_sto_max_cap_cumulative = {(u, y): 0.0 for u in H2_storage_unit for y in hor_yrs}
    h2_electrolysis_max_cap_cumulative = {(u, y): 0.0 for u in Elec_h2_units for y in hor_yrs}
    
    #####INITIALIZE DICTIONARIES TO STORE THE INVESTMENT VALUES FROM SUBPROBLEM####
    values_cap_inv = {}
    values_cap_inv_FC = {}
    values_heat_pump_dh_cap = {}
    values_heat_pump_ind_cap = {}
    values_trad_boiler_ind_cap_inv = {}
    values_trad_boiler_dh_cap_inv = {}
    values_stat_sto_cap_inv = {}
    values_h2_sto_max_cap = {}
    values_h2_electrolysis_max_cap = {}
    
    #####INITIALIZE DICTIONARIES TO STORE THE VARIABLE VALUES FROM SUBPROBLEM####
    generation_results = {}
    imports_results = {}
    ceep_results = {}
    cap_inv_results = {}
    noload_elec_results = {}
    noload_heat_ind_results = {}
    noload_heat_dh_results = {}
    CO2_total_results = {}
    CO2_total_heat_results = {}
    CO2_total_industry_results = {}
    cap_inv_FC_results = {}
    generation_FC_results = {}
    storage_level_results = {}
    sto_out_flow_results = {}
    heat_gen_results = {}
    Fuel_ind_results = {}
    H2tInd_results = {}
    heat_pump_dh_results = {}
    heat_pump_ind_results = {}
    heat_pump_dh_cap_results = {}
    heat_pump_ind_cap_results = {}
    boiler_dh_generation_results = {}
    boiler_ind_generation_results = {}
    trad_boiler_ind_cap_inv_results = {}
    trad_boiler_dh_cap_inv_results = {}
    ResToHeat_results = {}
    ev_sto_in_results = {}
    ev_sto_out_results = {}
    ev_sto_soc_results = {}
    stat_sto_in_results = {}
    stat_sto_out_results = {}
    stat_sto_cap_inv_results = {}
    power_to_h2_results = {}
    h2_sto_soc_results = {}
    h2_sto_out_results = {}
    h2_sto_max_cap_results = {}
    h2_electrolysis_max_cap_results = {}
    generation_H2_results = {}
    
    ########RUN THE LOOP OF SOLVING SUBPROBLEM AND UPDATION OF INVESTMENTS#########
    for i in range(len(hor_yrs)):
        years = hor_yrs[i : i + window]  # Update the list with a single year
        #scen = 'Subproblem_' + str(i) + '_' + str(hor_yrs[i])
        #scen  = 'Myopic_model'
        print(f"Building and solving the submodel for the year {hor_yrs[i]}")
        exec(open("scripts/Build_model_RH.py").read())
        print(f"Run for Submodel for the year {hor_yrs[i]} completed")
        
        
        ##############STORE VARIABLE VALUES FROM THE SUBPROBLEM####################
        
        for year in years:
            for unit in units:
                values_cap_inv[(unit, year)] = cap_inv[unit, year].X
    
            for unit in FC_units:
                values_cap_inv_FC[(unit, year)] = cap_inv_FC[unit, year].X
    
            for unit in HeatPump_units:
                values_heat_pump_ind_cap[(unit, year)] = heat_pump_ind_cap[unit, year].X
                for chp in chp_units:
                    values_heat_pump_dh_cap[(unit, chp, year)] = heat_pump_dh_cap[unit, chp, year].X
    
            for unit in thermal_units:
                values_trad_boiler_ind_cap_inv[(unit, year)] = trad_boiler_ind_cap_inv[unit, year].X
                for chp in chp_units:
                    values_trad_boiler_dh_cap_inv[(unit, chp, year)] = trad_boiler_dh_cap_inv[unit, chp, year].X
    
            for unit in Stat_storage_unit:
                values_stat_sto_cap_inv[(unit, year)] = stat_sto_cap_inv[unit, year].X
    
            for unit in H2_storage_unit:
                values_h2_sto_max_cap[(unit, year)] = h2_sto_max_cap[unit, year].X
    
            for unit in Elec_h2_units:
                values_h2_electrolysis_max_cap[(unit, year)] = h2_electrolysis_max_cap[unit, year].X    
        
        
        ##########UPDATE THE CUMULATIVE INVESTMENTS FOR THE NEXT SUBPROBLEM########
        for j in range(i + 1, min(i + 1 + window, len(hor_yrs))):
            for u in units:    
                cap_inv_cumulative[(u, hor_yrs[j])] = gp.quicksum(values_cap_inv[(u, hor_yrs[ip])] * round(((1-decom_rate[u])**(max(decom_start_new[u]-1, hor_yrs[j] - hor_yrs[ip]) - (decom_start_new[u]-1))), 3) for ip in range(len(hor_yrs)) if ip < j)
                
            for u in FC_units:    
                cap_inv_FC_cumulative[(u, hor_yrs[i+1])] = cap_inv_FC_cumulative[(u, hor_yrs[i])] + values_cap_inv_FC[(u, hor_yrs[i])]
    
            for u in HeatPump_units:
                heat_pump_ind_cap_cumulative[(u, hor_yrs[i+1])] = gp.quicksum(values_heat_pump_ind_cap[(u, hor_yrs[ip])] *round(((1-HP_decom_rate[u])**(max(HP_decom_start_new[u]-1, hor_yrs[i+1]-hor_yrs[ip])-(HP_decom_start_new[u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
                for v in chp_units:
                    heat_pump_dh_cap_cumulative[(u, v, hor_yrs[i+1])] = gp.quicksum(values_heat_pump_dh_cap[(u, v, hor_yrs[ip])] *round(((1-int(HP_decom_rate[u]))**(max(HP_decom_start_new[u]-1, hor_yrs[i+1]-hor_yrs[ip])-(HP_decom_start_new[u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
    
            for u in thermal_units:
                trad_boiler_ind_cap_inv_cumulative[(u, hor_yrs[i+1])] = gp.quicksum(values_trad_boiler_ind_cap_inv[(u, hor_yrs[ip])] *round(((1-int(Boiler_decom_rate[u]))**(max(Boiler_decom_start_new[u]-1,hor_yrs[i+1]-hor_yrs[ip])-(Boiler_decom_start_new[u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
                for v in chp_units:
                    trad_boiler_dh_cap_inv_cumulative[(u, v, hor_yrs[i+1])] = gp.quicksum(values_trad_boiler_dh_cap_inv[(u, v, hor_yrs[ip])] *round(((1-int(Boiler_decom_rate[u]))**(max(Boiler_decom_start_new[u]-1,hor_yrs[i+1]-hor_yrs[ip])-(Boiler_decom_start_new[u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
            
            for u in Stat_storage_unit:
                stat_sto_cap_inv_cumulative[(u, hor_yrs[i+1])] = gp.quicksum(values_stat_sto_cap_inv[(u, hor_yrs[ip])] *round(((1-Sta_sto_decom_rate[u])**(max(Sta_sto_decom_start_new[u]-1 ,hor_yrs[i+1]-hor_yrs[ip])-(Sta_sto_decom_start_new[u]-1))),3) for ip in range(len(hor_yrs)) if ip <= i)
                
            for u in H2_storage_unit:
                h2_sto_max_cap_cumulative[(u, hor_yrs[i+1])] = h2_sto_max_cap_cumulative[(u, hor_yrs[i])] + values_h2_sto_max_cap[(u, hor_yrs[i])]
            
            for u in Elec_h2_units:
                h2_electrolysis_max_cap_cumulative[(u, hor_yrs[i+1])] = h2_electrolysis_max_cap_cumulative[(u, hor_yrs[i])] + values_h2_electrolysis_max_cap[(u, hor_yrs[i])]
        
        ##############STORE VARIABLE VALUES FROM THE SUBPROBLEM####################
        
        for genco in units:
            cap_inv_results[genco, years[0]] = cap_inv[genco, years[0]].x
            for period in periods:
                generation_results[genco, period, years[0]] = generation[genco, period, years[0]].x
    
        for period in periods:
            imports_results[period, years[0]] = imports[period, years[0]].x
            ceep_results[period, years[0]] = ceep[period, years[0]].x
            noload_elec_results[period, years[0]] = noload_elec[period, years[0]].x
            noload_heat_ind_results[period, years[0]] = noload_heat_ind[period, years[0]].x
            ResToHeat_results[period, years[0]] = ResToHeat[period, years[0]].x
            ev_sto_in_results[period, years[0]] = ev_sto_in[period, years[0]].x
            ev_sto_out_results[period, years[0]] = ev_sto_out[period, years[0]].x
            ev_sto_soc_results[period, years[0]] = ev_sto_soc[period, years[0]].x
            power_to_h2_results[period, years[0]] = power_to_h2[period, years[0]].x
            H2tInd_results[period, years[0]] = H2tInd[period, years[0]].x
    
        for unit in chp_units:
            for period in periods:
                noload_heat_dh_results[unit, period, years[0]] = noload_heat_dh[unit, period, years[0]].x
                heat_gen_results[unit, period, years[0]] = heat_gen[unit, period, years[0]].x
    
        for unit in FC_units:
            cap_inv_FC_results[unit, years[0]] = cap_inv_FC[unit, years[0]].x
            for period in periods:
                generation_FC_results[unit, period, years[0]] = generation_FC[unit, period, years[0]].x
    
        for unit in hydro_storage_units:
            for period in periods:
                storage_level_results[unit, period, years[0]] = storage_level[unit, period, years[0]].x
                sto_out_flow_results[unit, period, years[0]] = sto_out_flow[unit, period, years[0]].x
    
        for fuel in industry_fuels:
            for period in periods:
                Fuel_ind_results[fuel, period, years[0]] = Fuel_ind[fuel, period, years[0]].x
    
        for hp_unit in HeatPump_units:
            heat_pump_ind_cap_results[hp_unit, years[0]] = heat_pump_ind_cap[hp_unit, years[0]].x
            for period in periods:
                heat_pump_ind_results[hp_unit, period, years[0]] = heat_pump_ind[hp_unit, period, years[0]].x
            for chp in chp_units:
                heat_pump_dh_cap_results[hp_unit, chp, years[0]] = heat_pump_dh_cap[hp_unit, chp, years[0]].x
                for period in periods:
                    heat_pump_dh_results[hp_unit, chp, period, years[0]] = heat_pump_dh[hp_unit, chp, period, years[0]].x
    
        for unit in thermal_units:
            trad_boiler_ind_cap_inv_results[unit, years[0]] = trad_boiler_ind_cap_inv[unit, years[0]].x
            for period in periods:
                boiler_ind_generation_results[unit, period, years[0]] = boiler_ind_generation[unit, period, years[0]].x
            for chp in chp_units:
                trad_boiler_dh_cap_inv_results[unit, chp, years[0]] = trad_boiler_dh_cap_inv[unit, chp, years[0]].x
                for period in periods:
                    boiler_dh_generation_results[unit, chp, period, years[0]] = boiler_dh_generation[unit, chp, period, years[0]].x
    
        for unit in Stat_storage_unit:
            stat_sto_cap_inv_results[unit, years[0]] = stat_sto_cap_inv[unit, years[0]].x
            for period in periods:
                stat_sto_in_results[unit, period, years[0]] = stat_sto_in[unit, period, years[0]].x
                stat_sto_out_results[unit, period, years[0]] = stat_sto_out[unit, period, years[0]].x
    
        for unit in H2_storage_unit:
            h2_sto_max_cap_results[unit, years[0]] = h2_sto_max_cap[unit, years[0]].x
            for period in periods:
                h2_sto_soc_results[unit, period, years[0]] = h2_sto_soc[unit, period, years[0]].x
                h2_sto_out_results[unit, period, years[0]] = h2_sto_out[unit, period, years[0]].x
    
        for unit in Elec_h2_units:
            h2_electrolysis_max_cap_results[unit, years[0]] = h2_electrolysis_max_cap[unit, years[0]].x
            for period in periods:
                generation_H2_results[unit, period, years[0]] = generation_H2[unit, period, years[0]].x
    
        CO2_total_results[years[0]] = CO2_total[years[0]].x
        CO2_total_heat_results[years[0]] = CO2_total_heat[years[0]].x
        CO2_total_industry_results[years[0]] = CO2_total_industry[years[0]].x    
    
    years = hor_yrs        
    exec(open("scripts/export_plot_RH.py").read())
    exec(open("scripts/combine_plot.py").read())