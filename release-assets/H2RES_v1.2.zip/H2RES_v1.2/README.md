﻿# H2RES v1.2

## Overview
H2RES v1.2 introduces a rolling-horizon execution pathway while preserving the core single-system sector-coupled logic of earlier versions.

## What improved relative to v1.1
Compared with v1.1, this version adds a new temporal solution strategy:
- the model can now be solved through rolling planning windows,
- cumulative investment states can be transferred across sequential optimization stages,
- time-horizon management becomes an explicit part of scenario design.

## Core capabilities
- All main modules from v1.1
- Rolling-horizon solution mode
- Standard full-horizon solution mode
- Explicit temporal controls through `years` and `window`
- Carry-over logic for cumulative investment decisions
- Auxiliary overflow investment variable for annual expansion flexibility
- Hydro-spillage cost represented in the objective

## New decision variables introduced in this version
- `extra_cap_inv_{u,y}`: auxiliary investment-overflow variable that allows annual expansion above the nominal cap when that pathway is explicitly activated in the formulation

## Main formulation changes relative to v1.1
- A rolling-horizon counterpart of the core model is introduced.
- Investment carry-over equations are used to transfer cumulative capacity decisions between planning windows.
- The temporal horizon is parameterized explicitly through `periods`, `years`, and `window`.
- The objective function penalizes hydro spillage and extra investment above the nominal annual expansion envelope.
- Some annual expansion relationships are reformulated so they can operate under sequential rolling-horizon solves.

## What remains unchanged from v1.1
- Single-system scope
- Same main sector-coupling architecture across electricity, heat, cooling, hydrogen, and storage
- Same broad policy structure for RPS and CO2 control
- Same central role of `read_process_data.py` and `Build_model.py`

## Main workflow
The active execution path is based on:
- `main.py`
- `scripts/read_process_data.py`
- `scripts/modeling_approaches.py`
- `scripts/Build_model.py`

## Recommended use
Use v1.2 when the research problem requires rolling-horizon analysis, staged investment decisions, or comparison between full-horizon and sequential solution strategies.

## Related documentation
For a full description of model structure, equations, data flow, and interpretation logic, see the corresponding User Manual and Mathematical Formulation documents for this version.

## Caution on cross-version comparison
This version is not just a new dataset or parameter update. It changes the temporal execution logic of the model. Results should therefore be interpreted with attention to the selected solution mode.
