﻿# H2RES v1.1

## Overview
H2RES v1.1 preserves the original single-system H2RES structure while improving the input-data workflow and extending adequacy-relaxation logic through explicit unmet-service variables.

## What improved relative to v1.0
Compared with v1.0, this version improves usability and transparency in two important ways:
- preprocessing is reorganized around direct CSV/XLSX inputs,
- explicit unmet-service variables are added to better represent scarcity in electricity and heat blocks.

## Core capabilities
- All core modules from v1.0
- Explicit unmet electricity-service representation
- Explicit unmet heat-service representation
- Scarcity penalties in the objective function
- Improved input-to-parameter traceability
- Continued support for heat, hydrogen, storage, and reserve modules

## New decision variables introduced in this version
- `noload_elec_{t,y}`: explicit unmet electricity-service variable
- `noload_heat_dh_{m,t,y}`: explicit unmet district-heating-service variable
- `noload_heat_ind_{t,y}`: explicit unmet industrial/general heat-service variable

## Main formulation changes relative to v1.0
- Electricity adequacy can be relaxed through `noload_elec_{t,y}` in addition to the original curtailment / slack structure.
- District-heating and industrial/general heat-service blocks can be relaxed through explicit unmet-service variables.
- The objective function now includes explicit no-load / lost-service penalties for unmet electricity and heat service.
- The data-preprocessing layer is reorganized so that the formulation is fed from direct CSV/XLSX input tables rather than the earlier workflow.

## What remains unchanged from v1.0
- Single-system model scope
- Core electricity, heat, cooling, hydrogen, storage, and policy architecture
- Main execution pattern based on `main.py`, `read_process_data.py`, and `Build_model.py`
- Optional reserve-module philosophy

## Main workflow
The standard execution path remains based on:
- `main.py`
- `scripts/read_process_data.py`
- `scripts/Build_model.py`

## Recommended use
Use v1.1 if you want the original H2RES logic with a cleaner and more accessible data-engineering workflow than v1.0.

## Related documentation
For a full description of model structure, equations, data flow, and interpretation logic, see the corresponding User Manual and Mathematical Formulation documents for this version.

## Caution on cross-version comparison
Although the physical scope is similar to v1.0, the input architecture and scarcity representation are not identical. Reproducibility across versions requires aligned assumptions.
